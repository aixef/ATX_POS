﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ATX_POS
{
    public partial class PaymentMix : UserControl
    {
        public PaymentMix()
        {
            InitializeComponent();
        }

        private void paymentCredit1_Load(object sender, EventArgs e)
        {

        }
    }
}
