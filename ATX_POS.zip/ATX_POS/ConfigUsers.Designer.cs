﻿namespace ATX_POS
{
    partial class ConfigUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NewUser = new MetroFramework.Controls.MetroButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.PermDetail = new System.Windows.Forms.TextBox();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.LevelPermiss = new System.Windows.Forms.ComboBox();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.Datepick = new MetroFramework.Controls.MetroDateTime();
            this.NoTerminal = new System.Windows.Forms.ComboBox();
            this.References = new System.Windows.Forms.TextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.State = new System.Windows.Forms.TextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.NumTerm = new System.Windows.Forms.TextBox();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.Address = new System.Windows.Forms.TextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.City = new System.Windows.Forms.TextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.Password = new System.Windows.Forms.TextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.SecondLastname = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.TextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.SecondName = new System.Windows.Forms.TextBox();
            this.FirstName = new System.Windows.Forms.TextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.Canceler = new MetroFramework.Controls.MetroButton();
            this.Acept = new MetroFramework.Controls.MetroButton();
            this.UserName = new System.Windows.Forms.TextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.Edit = new MetroFramework.Controls.MetroButton();
            this.ListUsers = new System.Windows.Forms.ComboBox();
            this.Delete = new MetroFramework.Controls.MetroButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.CancelPic = new System.Windows.Forms.PictureBox();
            this.EditPic = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CancelPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EditPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // NewUser
            // 
            this.NewUser.BackColor = System.Drawing.Color.White;
            this.NewUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NewUser.ForeColor = System.Drawing.Color.White;
            this.NewUser.Location = new System.Drawing.Point(54, 115);
            this.NewUser.Name = "NewUser";
            this.NewUser.Size = new System.Drawing.Size(68, 23);
            this.NewUser.Style = MetroFramework.MetroColorStyle.Teal;
            this.NewUser.TabIndex = 0;
            this.NewUser.Text = "Nuevo";
            this.NewUser.UseCustomBackColor = true;
            this.NewUser.UseSelectable = true;
            this.NewUser.UseStyleColors = true;
            this.NewUser.Click += new System.EventHandler(this.NewUser_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.PermDetail);
            this.groupBox1.Controls.Add(this.metroLabel11);
            this.groupBox1.Controls.Add(this.LevelPermiss);
            this.groupBox1.Controls.Add(this.metroLabel10);
            this.groupBox1.Controls.Add(this.Datepick);
            this.groupBox1.Controls.Add(this.NoTerminal);
            this.groupBox1.Controls.Add(this.References);
            this.groupBox1.Controls.Add(this.metroLabel5);
            this.groupBox1.Controls.Add(this.State);
            this.groupBox1.Controls.Add(this.metroLabel3);
            this.groupBox1.Controls.Add(this.NumTerm);
            this.groupBox1.Controls.Add(this.metroLabel14);
            this.groupBox1.Controls.Add(this.metroLabel13);
            this.groupBox1.Controls.Add(this.metroLabel7);
            this.groupBox1.Controls.Add(this.Address);
            this.groupBox1.Controls.Add(this.metroLabel9);
            this.groupBox1.Controls.Add(this.City);
            this.groupBox1.Controls.Add(this.metroLabel8);
            this.groupBox1.Controls.Add(this.Password);
            this.groupBox1.Controls.Add(this.metroLabel6);
            this.groupBox1.Controls.Add(this.SecondLastname);
            this.groupBox1.Controls.Add(this.LastName);
            this.groupBox1.Controls.Add(this.metroLabel4);
            this.groupBox1.Controls.Add(this.SecondName);
            this.groupBox1.Controls.Add(this.FirstName);
            this.groupBox1.Controls.Add(this.metroLabel2);
            this.groupBox1.Controls.Add(this.Canceler);
            this.groupBox1.Controls.Add(this.Acept);
            this.groupBox1.Controls.Add(this.UserName);
            this.groupBox1.Controls.Add(this.metroLabel1);
            this.groupBox1.Location = new System.Drawing.Point(23, 166);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(598, 292);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // PermDetail
            // 
            this.PermDetail.Location = new System.Drawing.Point(312, 261);
            this.PermDetail.Name = "PermDetail";
            this.PermDetail.ReadOnly = true;
            this.PermDetail.Size = new System.Drawing.Size(111, 20);
            this.PermDetail.TabIndex = 44;
            this.PermDetail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(337, 239);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(56, 19);
            this.metroLabel11.TabIndex = 43;
            this.metroLabel11.Text = "Permiso";
            // 
            // LevelPermiss
            // 
            this.LevelPermiss.Enabled = false;
            this.LevelPermiss.FormattingEnabled = true;
            this.LevelPermiss.Items.AddRange(new object[] {
            "",
            "1",
            "2",
            "3"});
            this.LevelPermiss.Location = new System.Drawing.Point(239, 260);
            this.LevelPermiss.Name = "LevelPermiss";
            this.LevelPermiss.Size = new System.Drawing.Size(44, 21);
            this.LevelPermiss.TabIndex = 9;
            this.LevelPermiss.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(219, 239);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(89, 19);
            this.metroLabel10.TabIndex = 42;
            this.metroLabel10.Text = "Nivel Permiso";
            // 
            // Datepick
            // 
            this.Datepick.Enabled = false;
            this.Datepick.FontSize = MetroFramework.MetroDateTimeSize.Small;
            this.Datepick.Location = new System.Drawing.Point(58, 260);
            this.Datepick.MinimumSize = new System.Drawing.Size(0, 25);
            this.Datepick.Name = "Datepick";
            this.Datepick.Size = new System.Drawing.Size(130, 25);
            this.Datepick.TabIndex = 8;
            // 
            // NoTerminal
            // 
            this.NoTerminal.Enabled = false;
            this.NoTerminal.FormattingEnabled = true;
            this.NoTerminal.Location = new System.Drawing.Point(397, 176);
            this.NoTerminal.Name = "NoTerminal";
            this.NoTerminal.Size = new System.Drawing.Size(44, 21);
            this.NoTerminal.TabIndex = 13;
            this.NoTerminal.SelectedIndexChanged += new System.EventHandler(this.NoTerminal_SelectedIndexChanged);
            this.NoTerminal.Click += new System.EventHandler(this.NoTerminal_Click);
            // 
            // References
            // 
            this.References.Location = new System.Drawing.Point(336, 83);
            this.References.Multiline = true;
            this.References.Name = "References";
            this.References.ReadOnly = true;
            this.References.Size = new System.Drawing.Size(222, 53);
            this.References.TabIndex = 12;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(336, 61);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(75, 19);
            this.metroLabel5.TabIndex = 38;
            this.metroLabel5.Text = "Referencias";
            // 
            // State
            // 
            this.State.Location = new System.Drawing.Point(458, 38);
            this.State.Name = "State";
            this.State.ReadOnly = true;
            this.State.Size = new System.Drawing.Size(100, 20);
            this.State.TabIndex = 11;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(458, 16);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(48, 19);
            this.metroLabel3.TabIndex = 36;
            this.metroLabel3.Text = "Estado";
            // 
            // NumTerm
            // 
            this.NumTerm.Location = new System.Drawing.Point(482, 177);
            this.NumTerm.Name = "NumTerm";
            this.NumTerm.ReadOnly = true;
            this.NumTerm.Size = new System.Drawing.Size(48, 20);
            this.NumTerm.TabIndex = 35;
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(477, 155);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(58, 19);
            this.metroLabel14.TabIndex = 34;
            this.metroLabel14.Text = "Número";
            this.metroLabel14.Click += new System.EventHandler(this.metroLabel14_Click);
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(387, 155);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(58, 19);
            this.metroLabel13.TabIndex = 32;
            this.metroLabel13.Text = "Terminal";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(58, 239);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(130, 19);
            this.metroLabel7.TabIndex = 20;
            this.metroLabel7.Text = "Fecha de nacimiento";
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(6, 177);
            this.Address.Multiline = true;
            this.Address.Name = "Address";
            this.Address.ReadOnly = true;
            this.Address.Size = new System.Drawing.Size(230, 47);
            this.Address.TabIndex = 7;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(6, 155);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(63, 19);
            this.metroLabel9.TabIndex = 24;
            this.metroLabel9.Text = "Direccion";
            // 
            // City
            // 
            this.City.Location = new System.Drawing.Point(336, 38);
            this.City.Name = "City";
            this.City.ReadOnly = true;
            this.City.Size = new System.Drawing.Size(100, 20);
            this.City.TabIndex = 10;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(336, 16);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(51, 19);
            this.metroLabel8.TabIndex = 22;
            this.metroLabel8.Text = "Ciudad";
            // 
            // Password
            // 
            this.Password.Location = new System.Drawing.Point(128, 38);
            this.Password.Name = "Password";
            this.Password.ReadOnly = true;
            this.Password.Size = new System.Drawing.Size(108, 20);
            this.Password.TabIndex = 2;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(136, 16);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(63, 19);
            this.metroLabel6.TabIndex = 18;
            this.metroLabel6.Text = "Password";
            // 
            // SecondLastname
            // 
            this.SecondLastname.Location = new System.Drawing.Point(128, 128);
            this.SecondLastname.Name = "SecondLastname";
            this.SecondLastname.ReadOnly = true;
            this.SecondLastname.Size = new System.Drawing.Size(108, 20);
            this.SecondLastname.TabIndex = 6;
            // 
            // LastName
            // 
            this.LastName.Location = new System.Drawing.Point(6, 128);
            this.LastName.Name = "LastName";
            this.LastName.ReadOnly = true;
            this.LastName.Size = new System.Drawing.Size(120, 20);
            this.LastName.TabIndex = 5;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(6, 106);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(63, 19);
            this.metroLabel4.TabIndex = 14;
            this.metroLabel4.Text = "Apellidos";
            // 
            // SecondName
            // 
            this.SecondName.Location = new System.Drawing.Point(128, 83);
            this.SecondName.Name = "SecondName";
            this.SecondName.ReadOnly = true;
            this.SecondName.Size = new System.Drawing.Size(108, 20);
            this.SecondName.TabIndex = 4;
            // 
            // FirstName
            // 
            this.FirstName.Location = new System.Drawing.Point(6, 83);
            this.FirstName.Name = "FirstName";
            this.FirstName.ReadOnly = true;
            this.FirstName.Size = new System.Drawing.Size(120, 20);
            this.FirstName.TabIndex = 3;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(6, 61);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(59, 19);
            this.metroLabel2.TabIndex = 10;
            this.metroLabel2.Text = "Nombre";
            // 
            // Canceler
            // 
            this.Canceler.BackColor = System.Drawing.Color.White;
            this.Canceler.ForeColor = System.Drawing.Color.White;
            this.Canceler.Location = new System.Drawing.Point(438, 258);
            this.Canceler.Name = "Canceler";
            this.Canceler.Size = new System.Drawing.Size(68, 23);
            this.Canceler.Style = MetroFramework.MetroColorStyle.Teal;
            this.Canceler.TabIndex = 8;
            this.Canceler.Text = "&Cancelar";
            this.Canceler.UseCustomBackColor = true;
            this.Canceler.UseSelectable = true;
            this.Canceler.UseStyleColors = true;
            this.Canceler.Click += new System.EventHandler(this.metroButton3_Click);
            // 
            // Acept
            // 
            this.Acept.BackColor = System.Drawing.Color.White;
            this.Acept.ForeColor = System.Drawing.Color.White;
            this.Acept.Location = new System.Drawing.Point(521, 258);
            this.Acept.Name = "Acept";
            this.Acept.Size = new System.Drawing.Size(68, 23);
            this.Acept.Style = MetroFramework.MetroColorStyle.Teal;
            this.Acept.TabIndex = 14;
            this.Acept.Text = "&Aceptar";
            this.Acept.UseCustomBackColor = true;
            this.Acept.UseSelectable = true;
            this.Acept.UseStyleColors = true;
            this.Acept.Click += new System.EventHandler(this.metroButton4_Click);
            // 
            // UserName
            // 
            this.UserName.Location = new System.Drawing.Point(6, 38);
            this.UserName.Name = "UserName";
            this.UserName.ReadOnly = true;
            this.UserName.Size = new System.Drawing.Size(120, 20);
            this.UserName.TabIndex = 1;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(6, 16);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(124, 19);
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "Nombre de usuario";
            // 
            // Edit
            // 
            this.Edit.BackColor = System.Drawing.Color.White;
            this.Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit.ForeColor = System.Drawing.Color.White;
            this.Edit.Location = new System.Drawing.Point(317, 115);
            this.Edit.Name = "Edit";
            this.Edit.Size = new System.Drawing.Size(68, 23);
            this.Edit.Style = MetroFramework.MetroColorStyle.Teal;
            this.Edit.TabIndex = 3;
            this.Edit.Text = "Editar";
            this.Edit.UseCustomBackColor = true;
            this.Edit.UseSelectable = true;
            this.Edit.UseStyleColors = true;
            this.Edit.Click += new System.EventHandler(this.Edit_Click);
            // 
            // ListUsers
            // 
            this.ListUsers.FormattingEnabled = true;
            this.ListUsers.Location = new System.Drawing.Point(190, 94);
            this.ListUsers.Name = "ListUsers";
            this.ListUsers.Size = new System.Drawing.Size(121, 21);
            this.ListUsers.TabIndex = 5;
            this.ListUsers.SelectedIndexChanged += new System.EventHandler(this.ListUsers_SelectedIndexChanged);
            this.ListUsers.Click += new System.EventHandler(this.ListUsers_Click);
            // 
            // Delete
            // 
            this.Delete.BackColor = System.Drawing.Color.White;
            this.Delete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Delete.ForeColor = System.Drawing.Color.White;
            this.Delete.Location = new System.Drawing.Point(393, 115);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(105, 23);
            this.Delete.Style = MetroFramework.MetroColorStyle.Teal;
            this.Delete.TabIndex = 6;
            this.Delete.Text = "Eliminar Usuario";
            this.Delete.UseCustomBackColor = true;
            this.Delete.UseSelectable = true;
            this.Delete.UseStyleColors = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.White;
            this.metroButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroButton1.ForeColor = System.Drawing.Color.White;
            this.metroButton1.Location = new System.Drawing.Point(506, 115);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(105, 23);
            this.metroButton1.Style = MetroFramework.MetroColorStyle.Teal;
            this.metroButton1.TabIndex = 8;
            this.metroButton1.Text = "Liberar Sesiones";
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.UseStyleColors = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::ATX_POS.Properties.Resources._1474428767_gnome_session_logout;
            this.pictureBox2.Location = new System.Drawing.Point(525, 64);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(68, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // CancelPic
            // 
            this.CancelPic.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CancelPic.Image = global::ATX_POS.Properties.Resources._1472783160_Remove_Male_User;
            this.CancelPic.Location = new System.Drawing.Point(412, 65);
            this.CancelPic.Name = "CancelPic";
            this.CancelPic.Size = new System.Drawing.Size(68, 50);
            this.CancelPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.CancelPic.TabIndex = 7;
            this.CancelPic.TabStop = false;
            this.CancelPic.Click += new System.EventHandler(this.Delete_Click);
            // 
            // EditPic
            // 
            this.EditPic.Cursor = System.Windows.Forms.Cursors.Hand;
            this.EditPic.Image = global::ATX_POS.Properties.Resources._1472782850_sign_up;
            this.EditPic.Location = new System.Drawing.Point(317, 65);
            this.EditPic.Name = "EditPic";
            this.EditPic.Size = new System.Drawing.Size(68, 50);
            this.EditPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.EditPic.TabIndex = 4;
            this.EditPic.TabStop = false;
            this.EditPic.Click += new System.EventHandler(this.Edit_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::ATX_POS.Properties.Resources._1472602250_user_group_new;
            this.pictureBox1.Location = new System.Drawing.Point(54, 65);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(68, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.NewUser_Click);
            // 
            // ConfigUsers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 481);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.CancelPic);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.ListUsers);
            this.Controls.Add(this.EditPic);
            this.Controls.Add(this.Edit);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.NewUser);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Movable = false;
            this.Name = "ConfigUsers";
            this.Text = "Configuración Usuarios";
            this.Load += new System.EventHandler(this.ConfigUsers_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CancelPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EditPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroButton NewUser;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox UserName;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private System.Windows.Forms.PictureBox EditPic;
        private MetroFramework.Controls.MetroButton Edit;
        private System.Windows.Forms.ComboBox ListUsers;
        private System.Windows.Forms.PictureBox CancelPic;
        private MetroFramework.Controls.MetroButton Delete;
        private System.Windows.Forms.TextBox References;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private System.Windows.Forms.TextBox State;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private System.Windows.Forms.TextBox NumTerm;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private System.Windows.Forms.TextBox Address;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private System.Windows.Forms.TextBox City;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private System.Windows.Forms.TextBox Password;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.TextBox SecondLastname;
        private System.Windows.Forms.TextBox LastName;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.TextBox SecondName;
        private System.Windows.Forms.TextBox FirstName;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroButton Canceler;
        private MetroFramework.Controls.MetroButton Acept;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroDateTime Datepick;
        private System.Windows.Forms.ComboBox NoTerminal;
        private System.Windows.Forms.TextBox PermDetail;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private System.Windows.Forms.ComboBox LevelPermiss;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private System.Windows.Forms.PictureBox pictureBox2;
        private MetroFramework.Controls.MetroButton metroButton1;

    }
}