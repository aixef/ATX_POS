﻿namespace ATX_POS
{
    partial class RCountingF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CloseBox = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.estadisticsBox1 = new ATX_POS.EstadisticsBox();
            this.cutBoxs1 = new ATX_POS.CutBoxs();
            this.metroProgressSpinner1 = new MetroFramework.Controls.MetroProgressSpinner();
            this.SuspendLayout();
            // 
            // CloseBox
            // 
            this.CloseBox.Image = null;
            this.CloseBox.Location = new System.Drawing.Point(208, 482);
            this.CloseBox.Name = "CloseBox";
            this.CloseBox.Size = new System.Drawing.Size(179, 27);
            this.CloseBox.TabIndex = 9;
            this.CloseBox.Text = "Cerrar Caja";
            this.CloseBox.UseSelectable = true;
            this.CloseBox.UseVisualStyleBackColor = true;
            this.CloseBox.Click += new System.EventHandler(this.metroTextButton1_Click_1);
            // 
            // estadisticsBox1
            // 
            this.estadisticsBox1.BackColor = System.Drawing.Color.Transparent;
            this.estadisticsBox1.Location = new System.Drawing.Point(23, 63);
            this.estadisticsBox1.Name = "estadisticsBox1";
            this.estadisticsBox1.Size = new System.Drawing.Size(326, 324);
            this.estadisticsBox1.TabIndex = 10;
            // 
            // cutBoxs1
            // 
            this.cutBoxs1.BackColor = System.Drawing.Color.Transparent;
            this.cutBoxs1.Location = new System.Drawing.Point(361, 120);
            this.cutBoxs1.Name = "cutBoxs1";
            this.cutBoxs1.Size = new System.Drawing.Size(226, 183);
            this.cutBoxs1.TabIndex = 11;
            // 
            // metroProgressSpinner1
            // 
            this.metroProgressSpinner1.Location = new System.Drawing.Point(268, 213);
            this.metroProgressSpinner1.Maximum = 100;
            this.metroProgressSpinner1.Name = "metroProgressSpinner1";
            this.metroProgressSpinner1.Size = new System.Drawing.Size(81, 65);
            this.metroProgressSpinner1.TabIndex = 12;
            this.metroProgressSpinner1.UseSelectable = true;
            // 
            // RCountingF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 552);
            this.Controls.Add(this.metroProgressSpinner1);
            this.Controls.Add(this.cutBoxs1);
            this.Controls.Add(this.estadisticsBox1);
            this.Controls.Add(this.CloseBox);
            this.Name = "RCountingF";
            this.Text = "Corte de Caja";
            this.Load += new System.EventHandler(this.RCountingF_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox.MetroTextButton CloseBox;
        private EstadisticsBox estadisticsBox1;
        private CutBoxs cutBoxs1;
        private MetroFramework.Controls.MetroProgressSpinner metroProgressSpinner1;
    }
}