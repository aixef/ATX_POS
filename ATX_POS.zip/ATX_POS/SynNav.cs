﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using System.Data.SqlClient;
using MetroFramework.Forms;
using System.Net;

//  using ATX_POS.Service_NAV;
//using ATX_POS.WS_NAV

namespace ATX_POS
{
    using PriceForItems;
    using CatalogoBancos;
    using MesureCodesFromNav;
    using ItemsListNAV;
    using DataCompanyNAV;
    using DataBranchNAV;

    class SynNav
    {
        string DateWork = DateTime.Today.ToString("MM/dd/yyyy");
        public void PrintBancos(ProgressBar bar, Form Princi)
        {
            CatalogoBancos.BancosSAT_Service services = new BancosSAT_Service();
            List<CatalogoBancos.BancosSAT_Filter> filter = new List<BancosSAT_Filter>();
            //services.UseDefaultCredentials = true;
            var networkcre = new NetworkCredential("admin", "P@ssword1");
            services.Credentials = networkcre;
            CatalogoBancos.BancosSAT[] list = services.ReadMultiple(filter.ToArray(), null, 10);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Bancos");
            bar.Value = 0;
            bar.Minimum = 0;
            bar.Maximum = Convert.ToInt32(list.Length.ToString());
            bar.Step = 1;
            foreach (BancosSAT BS in list)
            {
                InsertBanksSQL(BS, Princi);
                bar.PerformStep();
            }
            /*Ban.Credentials = Creden;

            ServicesSat.BancosSAT banks = new ServicesSat.BancosSAT();
            List<ServicesSat.BancosSAT_Filter> filterArray = new List<ServicesSat.BancosSAT_Filter>();
            ServicesSat.BancosSAT_Filter nameFilter = new ServicesSat.BancosSAT_Filter();
            nameFilter.Field = ServicesSat.BancosSAT_Fields.Name;
            nameFilter.Criteria = "*";
            filterArray.Add(nameFilter);
            filterArray.ToArray();

            ServicesSat.BancosSAT[] ListaBancos = BANCOS.ReadMultiple(filterArray,null,1);
            //banks[] list = BankSat.ReadMultiple(filter.ToArray(), null, 100);*/
            // return sb.ToString();

        }

        private void InsertBanksSQL(BancosSAT BS, Form Prin)
        {

            using (SqlConnection con = ConexionSQL.Cadenaconexion("ATX_POS"))
            {
                con.Open();
                SqlCommand command = new SqlCommand();
                command.Parameters.Clear();
                command.Connection = con;

                command.CommandText = ("Select Codebank from BankSAT where Codebank = @CodeBankNav");
                command.Parameters.AddWithValue("@CodeBankNav", BS.Code.ToString());
                int Exist = Convert.ToInt32(command.ExecuteScalar());
                if (Exist == 0)
                {
                    command.Parameters.Clear();
                    command.CommandText = ("Insert into BankSAT(Name,CodeBank,DatePosted) values(@NameBankNav, @CodeBankSATNav,@DatePosted)");
                    command.Parameters.AddWithValue("@CodeBankSATNav", BS.Code.ToString());
                    command.Parameters.AddWithValue("@DatePosted", DateWork);
                    command.Parameters.AddWithValue("@NameBankNav", BS.Name.ToString());
                    command.ExecuteScalar();
                }
                else if (Exist != 0)
                {
                    DialogResult result;
                    result = MessageBox.Show("El Registro ya existe en la base"
                                                                + System.Environment.NewLine
                                                                + "¿Desea Actualizarlo?", "Registro Duplicado", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (result == DialogResult.Yes)
                    {
                        command.Parameters.Clear();
                        command.CommandText = ("UPDATE BankSAT set Name = @NameBankNav, CodeBank = @CodeBankSATNav, LastModify = @DateModify where CodeBank = @CodeBankSATNav");
                        command.Parameters.AddWithValue("@CodeBankSATNav", BS.Code.ToString());
                        command.Parameters.AddWithValue("@DateModify", DateWork);
                        command.Parameters.AddWithValue("@NameBankNav", BS.Name.ToString());
                        command.ExecuteScalar();
                    }
                }
                con.Close();
            }

        }

        static string GetBank(BancosSAT BS)
        {
            return "Nombre Banco: " + BS.Name;
        }
    }


    class SynPrices
    {
        string DateWork = DateTime.Today.ToString("MM/dd/yyyy");

        public void items(ProgressBar BarItems)
        {
            PriceForItems.PriceItems_Service ItemsPricesNav = new PriceForItems.PriceItems_Service();
            PriceForItems.PriceItems_Filter ItemsFilter = new PriceForItems.PriceItems_Filter();
            var networkcre = new NetworkCredential("admin", "P@ssword1");
            ItemsPricesNav.Credentials = networkcre;
            //ItemsPricesNav.UseDefaultCredentials = true;
            List<PriceForItems.PriceItems_Filter> FilterItemsArray = new List<PriceForItems.PriceItems_Filter>();
            ItemsFilter.Field = PriceForItems.PriceItems_Fields.Bar_Code;
            ItemsFilter.Criteria = "=''";
            FilterItemsArray.Add(ItemsFilter);
            ItemsFilter.Field = PriceForItems.PriceItems_Fields.Sales_Type;
            ItemsFilter.Criteria = PriceForItems.Sales_Type.All_Customers.ToString();
            FilterItemsArray.Add(ItemsFilter);

            //ItemsFilter.Field = 
            //
            PriceForItems.PriceItems[] ListItems = ItemsPricesNav.ReadMultiple(FilterItemsArray.ToArray(), null, 1000);
            BarItems.Value = 0;
            BarItems.Minimum = 0;
            BarItems.Maximum = Convert.ToInt32(ListItems.Length.ToString());
            BarItems.Step = 1;

            foreach (PriceItems PI in ListItems)
            {
                InsertItemPrice(PI);
                BarItems.PerformStep();
            }
        }

        private void InsertItemPrice(PriceItems PI)
        {
            using (SqlConnection con = ConexionSQL.Cadenaconexion("ATX_POS"))
            {
                con.Open();
                SqlCommand command = new SqlCommand();
                command.Parameters.Clear();
                command.Connection = con;
                if (PI.Bar_Code != null)
                {
                    command.CommandText = ("Select BarCode from Items where BarCode = @CodeRefNAV");
                    command.Parameters.AddWithValue("@CodeRefNAV", PI.Bar_Code);
                    string Exist = (string)command.ExecuteScalar();
                    if (Exist == null)
                    {
                        command.Parameters.Clear();
                        command.CommandText = "Insert into Items(ItemName,ItemCode,Barcode,Price,IdMeasure,LastDateModified,[VAT Prod_ Posting Group],NoCodeNAV) values(@ItemName, @ItemCode,@Barcode,@Price,(select IdItemMeausere from MeasureItem where ItemMeasure=@IdMeasure),@LastDateModified,@VATPG,@NoCodeNAV)";
                        string vatIvaGrup = "";
                        string NameDescription = GetItemNameDescrip(PI.Item_No, ref vatIvaGrup);

                        command.Parameters.AddWithValue("@ItemName", NameDescription);
                        command.Parameters.AddWithValue("@ItemCode", PI.Bar_Code);
                        command.Parameters.AddWithValue("@BarCode", PI.Bar_Code);
                        command.Parameters.AddWithValue("@Price", PI.Unit_Price);
                        command.Parameters.AddWithValue("@IdMeasure", PI.Unit_of_Measure_Code);
                        command.Parameters.AddWithValue("@LastDateModified", DateWork);
                        command.Parameters.AddWithValue("@NoCodeNAV", PI.Item_No);
                        command.Parameters.AddWithValue("@VATPG", vatIvaGrup);
                        //command.Parameters.AddWithValue("@Alias","" );


                        //command.Parameters.AddWithValue("@NameBankNav", PI.Name.ToString());
                        command.ExecuteScalar();
                    }
                    else if (Exist != null)
                    {
                        DialogResult result;
                        result = MessageBox.Show("El Registro ya existe en la base"
                                                                    + System.Environment.NewLine
                                                                    + "¿Desea Actualizarlo?", "Registro Duplicado", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (result == DialogResult.Yes)
                        {
                            command.Parameters.Clear();
                            command.CommandText = ("UPDATE Items set Price = @Price, IdMeasure =(select IdItemMeausere from MeasureItem where ItemMeasure = @ItemMeasure), LastDateModified = @LastDateModified where BarCode = @BarCode");
                            command.Parameters.AddWithValue("@Price", PI.Unit_Price);
                            command.Parameters.AddWithValue("@ItemMeasure", PI.Unit_of_Measure_Code);
                            command.Parameters.AddWithValue("@LastDateModified", DateWork);
                            command.Parameters.AddWithValue("@BarCode", PI.Bar_Code);
                            command.ExecuteScalar();
                        }
                    }
                    con.Close();
                }
            }
        }

        private string GetVatIvaGrup(string p)
        {
            throw new NotImplementedException();
        }

        private string GetItemNameDescrip(string p, ref string VatIVA)
        {
            string Description = "";
            ItemsListNAV.ItemsList_Service ItemListServ = new ItemsListNAV.ItemsList_Service();
            ItemsListNAV.ItemsList_Filter ItemListFilter = new ItemsListNAV.ItemsList_Filter();
            //            ItemListServ.UseDefaultCredentials = true;
            var networkcre = new NetworkCredential("admin", "P@ssword1");
            ItemListServ.Credentials = networkcre;


            ItemListFilter.Field = ItemsListNAV.ItemsList_Fields.No;
            ItemListFilter.Criteria = "=" + p;
            List<ItemsListNAV.ItemsList_Filter> ItemsListFilterArray = new List<ItemsListNAV.ItemsList_Filter>();
            ItemsListFilterArray.Add(ItemListFilter);

            //ItemsFilter.Field = 
            //
            ItemsListNAV.ItemsList[] ListItems = ItemListServ.ReadMultiple(ItemsListFilterArray.ToArray(), null, 1);
            foreach (ItemsList IL in ListItems)
            {
                Description = IL.Description;
                VatIVA = IL.VAT_Prod_Posting_Group;
            }

            return Description;
        }
    }

    class SyncMesureCodes
    {
        string DateWork = DateTime.Today.ToString("MM/dd/yyyy");
        public void MesureCodes(ProgressBar BarMesure)
        {
            //ItemMeasure
            MesureCodesFromNav.MesureC_Service MesureCodeServices = new MesureC_Service();
            var networkcre = new NetworkCredential("admin", "P@ssword1");
            MesureCodeServices.Credentials = networkcre;
            List<MesureC_Filter> MesureFilterArray = new List<MesureC_Filter>();

            MesureC[] list = MesureCodeServices.ReadMultiple(MesureFilterArray.ToArray(), null, 100);

            BarMesure.Minimum = 0;
            BarMesure.Maximum = Convert.ToInt32(list.Length);
            BarMesure.Step = 1;

            foreach (MesureC MC in list)
            {
                InsertMesureCodes(MC);
                BarMesure.PerformStep();
            }

        }
        public void InsertMesureCodes(MesureC MesureCs)
        {

            using (SqlConnection con = ConexionSQL.Cadenaconexion("ATX_POS"))
            {
                con.Open();
                SqlCommand command = new SqlCommand();
                command.Parameters.Clear();
                command.Connection = con;

                command.CommandText = ("Select COUNT(ItemMeasure) from MeasureItem where ItemMeasure = @CodeMesureNav");
                command.Parameters.AddWithValue("@CodeMesureNav", MesureCs.Code.ToString());
                int Exist = (int)command.ExecuteScalar();// command.ExecuteNonQuery().ToString();
                if (Exist == 0)
                {
                    command.Parameters.Clear();
                    command.CommandText = ("Insert into MeasureItem(IdItemMeausere,ItemMeasure,Description, DateInserted) values(@IdItemMeausere,@ItemCodeNav, @DesciptionNAV, @DatePosted)");
                    command.Parameters.AddWithValue("@IdItemMeausere", MesureCs.Code.ToString());
                    command.Parameters.AddWithValue("@ItemCodeNav", MesureCs.Code.ToString());
                    command.Parameters.AddWithValue("@DesciptionNAV", MesureCs.Description.ToString());
                    //command.Parameters.AddWithValue("@InternationalCode", MesureCs.International_Standard_Code.ToString());
                    command.Parameters.AddWithValue("@DatePosted", DateWork);
                    command.ExecuteScalar();
                }
                else if (Exist != 0)
                {
                    DialogResult result;
                    result = MessageBox.Show("El Registro ya existe en la base"
                                                                + System.Environment.NewLine
                                                                + "¿Desea Actualizarlo?", "Registro Duplicado", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (result == DialogResult.Yes)
                    {
                        command.Parameters.Clear();
                        command.CommandText = ("UPDATE MeasureItem set ItemMeasure = @ItemCodeNav, Description = @DesciptionNAV, LastModify = @DateModify where IdItemMeausere = @ItemCodeNav");
                        //command.CommandText = ("Insert into MeasureItem(ItemMeasure,Description,International_Code) values(@ItemCodeNav, @DesciptionNAV, @InternationalCode)");
                        command.Parameters.AddWithValue("@ItemCodeNav", MesureCs.Code.ToString());
                        command.Parameters.AddWithValue("@DesciptionNAV", MesureCs.Description.ToString());
                        //command.Parameters.AddWithValue("@InternationalCode", MesureCs.International_Standard_Code.ToString());
                        command.Parameters.AddWithValue("@DateModify", DateWork);
                        command.ExecuteScalar();
                    }
                }
                con.Close();
            }

        }

    }

    class SyncCompany
    {
        string DateWork = DateTime.Today.ToString("MM/dd/yyyy");
        public void DatCompanyFromNav()
        {
            //ItemMeasure
            DataCompanyNAV.DataCompany_Service DataComNavSer = new DataCompany_Service();

            var networkcre = new NetworkCredential("admin", "P@ssword1");
            DataComNavSer.Credentials = networkcre;
            List<DataCompany_Filter> CompanyFilterArray = new List<DataCompany_Filter>();
            DataCompany[] list = DataComNavSer.ReadMultiple(CompanyFilterArray.ToArray(), null, 100);
            foreach (DataCompany DC in list)
            {
                UpdateDatacompany(DC);
            }

        }

        private void UpdateDatacompany(DataCompany DC)
        {
            using (SqlConnection con = ConexionSQL.Cadenaconexion("ATX_POS"))
            {
                con.Open();
                SqlCommand command = new SqlCommand();
                command.Parameters.Clear();
                command.Connection = con;

                command.CommandText = ("Select TOP 1 [NameCompany] from Company where [no] <> 0");
                string Exist = command.ExecuteScalar().ToString();
                if (Exist == null)
                {
                    command.Parameters.Clear();
                    command.CommandText = ("Insert into Company ([NameCompany],[Location],[RFC],[PCode],[City],[StateMex],[Email],[Phone]) values(@NameCompany,@Location,@RFC,@PCode,@City,@StateMex,@Email,@Phone)");
                    command.Parameters.AddWithValue("@NameCompany", DC.Name.ToString());
                    command.Parameters.AddWithValue("@Location", (DC.Address.ToString() + ", " + DC.Address_2.ToString()));
                    command.Parameters.AddWithValue("@RFC", DC.VAT_Registration_No.ToString());
                    command.Parameters.AddWithValue("@PCode", DC.Post_Code.ToString());
                    command.Parameters.AddWithValue("@City", DC.City.ToString());
                    command.Parameters.AddWithValue("@StateMex", DC.County.ToString());
                    command.Parameters.AddWithValue("@Email", DC.E_Mail.ToString());
                    command.Parameters.AddWithValue("@Phone", DC.Phone_No.ToString());
                    command.ExecuteScalar();
                }
                else if (Exist != null)
                {
                    DialogResult result;
                    result = MessageBox.Show("Se modificaran los datos de la empresa en la base local"
                                                                + System.Environment.NewLine
                                                                + "¿Desea continuar?", "Registro Duplicado", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (result == DialogResult.Yes)
                    {
                        command.Parameters.Clear();
                        command.CommandText = ("UPDATE Company set [NameCompany] = @NameCompany,[Location] = @Location,[RFC] = @RFC,[PCode] = @PCode,[City] = @City,[StateMex] = @StateMex,[Email] = @Email,[Phone] = @Phone where [no] > 0");
                        command.Parameters.AddWithValue("@NameCompany", DC.Name.ToString());
                        command.Parameters.AddWithValue("@Location", (DC.Address.ToString() +", "+ DC.Address_2.ToString()));
                        command.Parameters.AddWithValue("@RFC", DC.VAT_Registration_No.ToString());
                        command.Parameters.AddWithValue("@PCode", DC.Post_Code.ToString());
                        command.Parameters.AddWithValue("@City", DC.City.ToString());
                        command.Parameters.AddWithValue("@StateMex", DC.County.ToString());
                        command.Parameters.AddWithValue("@Email", DC.E_Mail.ToString());
                        command.Parameters.AddWithValue("@Phone", DC.Phone_No.ToString());
                        try
                        {
                            command.ExecuteNonQuery();
                            
                        }
                        catch (SqlException sqle)
                        {
                            MessageBox.Show(sqle.Message);
                        }
                    }
                }
                con.Close();
            }

        }
    }

}
