﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Collections;
using System.Net;
using ATX_POS.WS_NAV;


namespace ATX_POS
{
    using PagosNAV;
    public partial class RCountingF : MetroFramework.Forms.MetroForm
    {
        public string user;
        public string terminal;
        string datework = DateTime.Today.ToString("MM/dd/yyyy");
        decimal totalcreditsales = 0M;
        decimal totaldebit = 0M;
        decimal totaloutsM = 0M, totalchangescash = 0M, totalOT = 0M;
        decimal salestotalcashing = 0M;
        decimal totalcounUp = 0M;
        decimal cashinBox = 0M;
        ArrayList UsersNoClose = new ArrayList();
        public RCountingF()
        {
            InitializeComponent();
            
        }

        private void RCountingF_Load(object sender, EventArgs e)
        {
            metroProgressSpinner1.Maximum = 100;
            metroProgressSpinner1.Value = 50;
        }
        public void GetAllStatics()
        {
            using (SqlConnection CN = ConexionSQL.Cadenaconexion("ATX_POS"))
            {
                //LashcutCount(CN);
                TotalCountings(CN);
                TotalSalesCash(CN);
                Totalcreditsales(CN);
                TotalDebitSales(CN);
                TotalOutsTerm(CN);
                //LashcutCount(CN);
                Checkconnection(CN);
            }
        }
        public void checkusr()
        {
            using (SqlConnection CN = ConexionSQL.Cadenaconexion("ATX_POS"))
            {
                LashcutCount(CN);
                Checkconnection(CN);
            }
        }
        private void LashcutCount(SqlConnection CN)
        {
            Checkconnection(CN);
            bool checking = CheckSesions(CN);
            if (checking)
            {
                CN.Open();
                SqlCommand getLastCounting = new SqlCommand();
                getLastCounting.Parameters.Clear();
                getLastCounting.Connection = CN;
                getLastCounting.CommandText = "";
                getLastCounting.Parameters.AddWithValue("", "");
            }
            else
            {
                string users = "";
                int userscount = 0;
                foreach (object obj in UsersNoClose)
                {
                    users += (obj+", ");
                }
                if (userscount < 2)
                {
                    MetroFramework.MetroMessageBox.Show(this, "El usuario " + users + "No ha realizado su corte de Turno", "Corte de Turno Faltante", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MetroFramework.MetroMessageBox.Show(this, "Los Usuarios " + users + "No han realizado su corte de Turno", "Corte de Turno Faltante", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                CloseBox.Enabled = false;
            }
            Checkconnection(CN);
        }

        private bool CheckSesions(SqlConnection CN)
        {
            bool allsessionclose = true;
            Checkconnection(CN);
            CN.Open();
            SqlCommand checksessions = new SqlCommand();
            checksessions.Parameters.Clear();
            checksessions.Connection = CN;
            checksessions.CommandText = "select [Cierreturno], [User] from LoginsControl where [DateWork] = @datework and [Terminal] = @Terminal";
            checksessions.Parameters.AddWithValue("@datework", datework);
            checksessions.Parameters.AddWithValue("@Terminal",terminal);
            SqlDataAdapter sdacheck = new SqlDataAdapter(checksessions);
            DataTable checktb = new DataTable();
            if (sdacheck != null)
            {
                sdacheck.Fill(checktb);
            }
            foreach (DataRow row in checktb.Rows)
            {
                bool closeturn = bool.Parse(row[0].ToString());
                if (closeturn == false)
                {
                    UsersNoClose.Add(row[1].ToString());
                    allsessionclose = false;
                }
            }

            CN.Close();
            Checkconnection(CN);
            return allsessionclose;
        }

        private void Checkconnection(SqlConnection CN)
        {
            if (CN.State == ConnectionState.Open)
            {
                CN.Close();
            }
        }

        private void TotalOutsTerm(SqlConnection CN)
        {
            Checkconnection(CN);
            SqlCommand totaloutsterm = new SqlCommand();
            //total manual outs
            #region manualouts
            totaloutsterm.Parameters.Clear();
            CN.Open();
            totaloutsterm.Connection = CN;
            totaloutsterm.CommandText = "select COALESCE(SUM([Total]),0) from CashOut where [Date] = @Datework and [Terminal] = (select [Terminal] from Terminals where [Number] = @Terminal)";
            totaloutsterm.Parameters.AddWithValue("@Datework",datework);
            totaloutsterm.Parameters.AddWithValue("@Terminal", terminal);
            SqlDataAdapter totalDA = new SqlDataAdapter(totaloutsterm);
            DataTable totalouttable = new DataTable();
            if (totalDA != null)
            {
                totalDA.Fill(totalouttable);
            }
            Checkconnection(CN);
            foreach (DataRow row in totalouttable.Rows)
            {
                totaloutsM = decimal.Parse(row[0].ToString());
            }
            #endregion
            //total changes
            #region Totalchanges
            totaloutsterm.Parameters.Clear();
            CN.Open();
            totaloutsterm.CommandText = "select Coalesce(SUM([ChangeCash]),0) FROM PaymentsDetail where [DateReg] = @datework and [terminalUse] = @terminal";
            totaloutsterm.Parameters.AddWithValue("@datework", datework);
            totaloutsterm.Parameters.AddWithValue("@terminal",terminal);
            SqlDataAdapter totalchaDA = new SqlDataAdapter(totaloutsterm);
            DataTable totalchatb = new DataTable();
            if (totalchaDA != null)
            {
                totalchaDA.Fill(totalchatb);
            }
            foreach (DataRow row in totalchatb.Rows)
            {
                totalchangescash = decimal.Parse(row[0].ToString());
            }
            #endregion
            //totalouts
            totalOT = totaloutsM + totalchangescash;
            estadisticsBox1.Totalouts.Text = totalOT.ToString("N2");
            Checkconnection(CN);
        }

        private void TotalDebitSales(SqlConnection CN)
        {
            Checkconnection(CN);
            SqlCommand totaldebits = new SqlCommand();
            CN.Open();
            totaldebits.Parameters.Clear();
            totaldebits.CommandText = "select COALESCE (SUM([Total]),0) from CardsDetail where ([Debit] = @Debit OR [Vales] = @Vales) and [DateReg] = @datework and [NumTerm] = @terminal";
            totaldebits.Connection = CN;
            totaldebits.Parameters.AddWithValue("@terminal", terminal);
            totaldebits.Parameters.AddWithValue("@Debit", true);
            totaldebits.Parameters.AddWithValue("@Vales", true);
            totaldebits.Parameters.AddWithValue("@datework", datework);
            SqlDataAdapter debitad = new SqlDataAdapter(totaldebits);
            DataTable debittb = new DataTable();
            if (debitad !=null)
            {
                debitad.Fill(debittb);
            }
            foreach (DataRow row in debittb.Rows)
            {
                totaldebit = decimal.Parse(row[0].ToString());
            }
            estadisticsBox1.debittotal.Text = totaldebit.ToString("N2");
            Checkconnection(CN);
        }

        private void Totalcreditsales(SqlConnection CN)
        {
            Checkconnection(CN);
            SqlCommand totalcredisql = new SqlCommand();
            CN.Open();
            totalcredisql.Parameters.Clear();
            totalcredisql.CommandText = "select COALESCE (SUM([Total]),0) from CardsDetail where ([Credit] =@Credit) and [DateReg] = @datework and [NumTerm] = @terminal";
            totalcredisql.Connection = CN;
            totalcredisql.Parameters.AddWithValue("@terminal", terminal);
            totalcredisql.Parameters.AddWithValue("@Credit", true);
            totalcredisql.Parameters.AddWithValue("@datework", datework);
            SqlDataAdapter creditsda = new SqlDataAdapter(totalcredisql);
            DataTable creditb = new DataTable();
            if (creditsda != null)
            {
                creditsda.Fill(creditb);
            }
            foreach (DataRow row in creditb.Rows)
            {
                totalcreditsales = decimal.Parse(row[0].ToString());
            }
            estadisticsBox1.CreditTotal.Text = totalcreditsales.ToString("N2");
            Checkconnection(CN);  
        }

        private void TotalSalesCash(SqlConnection CN)
        {
            Checkconnection(CN);
            SqlCommand salescash = new SqlCommand();
            CN.Open();
            salescash.Parameters.Clear();
            salescash.Connection = CN;
            salescash.CommandText = "select coalesce(SUM([SalesTotal]),0) FROM PaymentsDetail where [DateReg] = @datereg and [terminalUse] = @terminal";
            salescash.Parameters.AddWithValue("@terminal",terminal);
            salescash.Parameters.AddWithValue("@datereg",datework);
            SqlDataAdapter salessda = new SqlDataAdapter(salescash);
            DataTable salesdt = new DataTable();
            if (salessda != null)
            {
                salessda.Fill(salesdt);
            }
            foreach (DataRow row in salesdt.Rows)
            {
                salestotalcashing = decimal.Parse(row[0].ToString());
            }
            estadisticsBox1.salescash.Text = salestotalcashing.ToString("N2");
            Checkconnection(CN);
        }

        private void TotalCountings(SqlConnection CN)
        {
            Checkconnection(CN);
            SqlCommand Totalcountings = new SqlCommand();
            CN.Open();
            Totalcountings.Parameters.Clear();
            Totalcountings.Connection = CN;
            Totalcountings.CommandText = "select COALESCE(SUM([TotalCounting]),0) from CountingUp where [DateCounting] = @datework  and [Teriminal] = (select Terminal from Terminals where Number = @terminal)";
            Totalcountings.Parameters.AddWithValue("@datework", datework);
            Totalcountings.Parameters.AddWithValue("@terminal", terminal);
            SqlDataAdapter countsda = new SqlDataAdapter(Totalcountings);
            DataTable countdt = new DataTable();
            if (countsda != null)
            {
                countsda.Fill(countdt);
            }
            foreach (DataRow row in countdt.Rows)
            {
                totalcounUp = decimal.Parse(row[0].ToString());
            }
            estadisticsBox1.TotalCasingUps.Text = totalcounUp.ToString("N2");
            Checkconnection(CN);
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
        private void metroTextButton1_Click(object sender, EventArgs e)
        {

        }
        private void metroTextButton1_Click_1(object sender, EventArgs e)
        {
            sendpayments();
        }

        private void sendpayments()
        {
            //MetroFramework.Controls.MetroProgressSpinner spiner= new MetroFramework.Controls.MetroProgressSpinner();
            //this.Controls.Add(this.spiner);
            metroProgressSpinner1.Maximum = 100;
            metroProgressSpinner1.Value = 50;
            PagosNAV.PagosToNav_Service PaymentsService = new PagosToNav_Service();
            //Credenciales de acceso
            var networkcre = new NetworkCredential("admin", "P@ssword1");
            PaymentsService.Credentials = networkcre;
            PagosToNav payment = new PagosToNav();
            PaymentsService.Create("POSCASH", ref payment);
            payment.Posting_Date = DateTime.Today;
            //payment.Document_Type = Document_Type.Payment;
            payment.Account_Type = Account_Type.G_L_Account;
            payment.Bal_Account_No = "1220";
            payment.Recipient_Bank_Account = "0001102";
            payment.Payment_Method_Code = "01";
            payment.Amount= 1122;
            PaymentsService.Update("POSCASH", ref payment);
        }
        private void salesInDetail1_Load(object sender, EventArgs e)
        {

        }
    }
}
