﻿namespace ATX_POS
{
    partial class SyncPriceLists
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SyncPriceLists));
            this.TabsPOS = new MetroFramework.Controls.MetroTabControl();
            this.TabTerminal = new MetroFramework.Controls.MetroTabPage();
            this.RegistrarVenta = new MetroFramework.Controls.MetroTile();
            this.TotalConten = new MetroFramework.Controls.MetroLabel();
            this.TotalLabel = new MetroFramework.Controls.MetroLabel();
            this.IvaConLabel = new MetroFramework.Controls.MetroLabel();
            this.IVALabel = new MetroFramework.Controls.MetroLabel();
            this.SubTotalConLabel = new MetroFramework.Controls.MetroLabel();
            this.CodeTextbox = new System.Windows.Forms.TextBox();
            this.SubTotalLabel = new MetroFramework.Controls.MetroLabel();
            this.CodeLabel = new MetroFramework.Controls.MetroLabel();
            this.ItemsDataGrid = new MetroFramework.Controls.MetroGrid();
            this.SyncNav = new MetroFramework.Controls.MetroTabPage();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.GetDatSuc = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.GetDataComp = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.MesureBar = new MetroFramework.Controls.MetroProgressBar();
            this.SyncMeasures = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.progressItemsPrice = new MetroFramework.Controls.MetroProgressBar();
            this.metroTextButton3 = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.ProgressNavBanks = new MetroFramework.Controls.MetroProgressBar();
            this.SycnBanks = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.UploadNav = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.Config = new MetroFramework.Controls.MetroTabPage();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.metroTextButton4 = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.metroTextButton2 = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.metroTextButton1 = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.Footer = new System.Windows.Forms.TextBox();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.TerminalConfig = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.ConfigUsersboton = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.PhoneSuc = new System.Windows.Forms.TextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.CodeNavStore = new System.Windows.Forms.TextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.CompanyPhone = new System.Windows.Forms.TextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.LocSucText = new System.Windows.Forms.TextBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.SucNameText = new System.Windows.Forms.TextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.RFC = new System.Windows.Forms.TextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.CompanyLocation = new System.Windows.Forms.TextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.NameCompany = new System.Windows.Forms.TextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.TabCashOut = new MetroFramework.Controls.MetroTabPage();
            this.CashManualOut = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.CorteCaja = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.CorteFin = new MetroFramework.Controls.MetroTextBox.MetroTextButton();
            this.TermAsing = new MetroFramework.Controls.MetroLabel();
            this.UseTerminal = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.SalesLabelContent = new MetroFramework.Controls.MetroLabel();
            this.SalesTotalLabel = new MetroFramework.Controls.MetroLabel();
            this.CurrencyPicture = new System.Windows.Forms.PictureBox();
            this.NameUserLabelCont = new MetroFramework.Controls.MetroLabel();
            this.UserNameLabel = new MetroFramework.Controls.MetroLabel();
            this.ListOfUsers = new MetroFramework.Controls.MetroComboBox();
            this.ImagenUser = new System.Windows.Forms.PictureBox();
            this.labelUser = new System.Windows.Forms.Label();
            this.UserLabel = new System.Windows.Forms.Label();
            this.LabelTerminal = new System.Windows.Forms.Label();
            this.MenuGrid = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.BorrarArticulo = new System.Windows.Forms.ToolStripMenuItem();
            this.TimerLabel = new MetroFramework.Controls.MetroLabel();
            this.NoTerminal = new MetroFramework.Controls.MetroLabel();
            this.Logo = new System.Windows.Forms.PictureBox();
            this.LogOut = new System.Windows.Forms.PictureBox();
            this.salesInDetail1 = new ATX_POS.SalesInDetail();
            this.cashCount1 = new ATX_POS.CashCount();
            this.TabsPOS.SuspendLayout();
            this.TabTerminal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemsDataGrid)).BeginInit();
            this.SyncNav.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.Config.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            this.TabCashOut.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CurrencyPicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImagenUser)).BeginInit();
            this.MenuGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogOut)).BeginInit();
            this.SuspendLayout();
            // 
            // TabsPOS
            // 
            this.TabsPOS.Controls.Add(this.TabTerminal);
            this.TabsPOS.Controls.Add(this.Config);
            this.TabsPOS.Controls.Add(this.SyncNav);
            this.TabsPOS.Controls.Add(this.TabCashOut);
            this.TabsPOS.ItemSize = new System.Drawing.Size(200, 40);
            this.TabsPOS.Location = new System.Drawing.Point(23, 94);
            this.TabsPOS.Name = "TabsPOS";
            this.TabsPOS.SelectedIndex = 0;
            this.TabsPOS.Size = new System.Drawing.Size(747, 460);
            this.TabsPOS.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.TabsPOS.TabIndex = 0;
            this.TabsPOS.UseSelectable = true;
            this.TabsPOS.SelectedIndexChanged += new System.EventHandler(this.TabsPOS_SelectedIndexChanged);
            // 
            // TabTerminal
            // 
            this.TabTerminal.BackColor = System.Drawing.Color.White;
            this.TabTerminal.Controls.Add(this.RegistrarVenta);
            this.TabTerminal.Controls.Add(this.TotalConten);
            this.TabTerminal.Controls.Add(this.TotalLabel);
            this.TabTerminal.Controls.Add(this.IvaConLabel);
            this.TabTerminal.Controls.Add(this.IVALabel);
            this.TabTerminal.Controls.Add(this.SubTotalConLabel);
            this.TabTerminal.Controls.Add(this.CodeTextbox);
            this.TabTerminal.Controls.Add(this.SubTotalLabel);
            this.TabTerminal.Controls.Add(this.CodeLabel);
            this.TabTerminal.Controls.Add(this.ItemsDataGrid);
            this.TabTerminal.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TabTerminal.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabTerminal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(32)))), ((int)(((byte)(116)))));
            this.TabTerminal.HorizontalScrollbarBarColor = true;
            this.TabTerminal.HorizontalScrollbarHighlightOnWheel = false;
            this.TabTerminal.HorizontalScrollbarSize = 10;
            this.TabTerminal.Location = new System.Drawing.Point(4, 44);
            this.TabTerminal.Name = "TabTerminal";
            this.TabTerminal.Size = new System.Drawing.Size(739, 412);
            this.TabTerminal.TabIndex = 0;
            this.TabTerminal.Text = "Terminal";
            this.TabTerminal.UseCustomForeColor = true;
            this.TabTerminal.VerticalScrollbarBarColor = true;
            this.TabTerminal.VerticalScrollbarHighlightOnWheel = false;
            this.TabTerminal.VerticalScrollbarSize = 10;
            this.TabTerminal.Click += new System.EventHandler(this.TabTerminal_Click);
            // 
            // RegistrarVenta
            // 
            this.RegistrarVenta.ActiveControl = null;
            this.RegistrarVenta.BackColor = System.Drawing.Color.Transparent;
            this.RegistrarVenta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RegistrarVenta.ForeColor = System.Drawing.Color.White;
            this.RegistrarVenta.Location = new System.Drawing.Point(577, 258);
            this.RegistrarVenta.Name = "RegistrarVenta";
            this.RegistrarVenta.Size = new System.Drawing.Size(100, 23);
            this.RegistrarVenta.Style = MetroFramework.MetroColorStyle.Green;
            this.RegistrarVenta.TabIndex = 17;
            this.RegistrarVenta.Text = "&Registrar";
            this.RegistrarVenta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.RegistrarVenta.UseCustomForeColor = true;
            this.RegistrarVenta.UseSelectable = true;
            this.RegistrarVenta.UseStyleColors = true;
            this.RegistrarVenta.Click += new System.EventHandler(this.RegistrarVenta_Click);
            // 
            // TotalConten
            // 
            this.TotalConten.AutoSize = true;
            this.TotalConten.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TotalConten.ForeColor = System.Drawing.Color.Black;
            this.TotalConten.Location = new System.Drawing.Point(577, 207);
            this.TotalConten.MinimumSize = new System.Drawing.Size(100, 20);
            this.TotalConten.Name = "TotalConten";
            this.TotalConten.Size = new System.Drawing.Size(0, 0);
            this.TotalConten.Style = MetroFramework.MetroColorStyle.Blue;
            this.TotalConten.TabIndex = 15;
            this.TotalConten.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.TotalConten.UseStyleColors = true;
            // 
            // TotalLabel
            // 
            this.TotalLabel.AutoSize = true;
            this.TotalLabel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TotalLabel.Location = new System.Drawing.Point(577, 173);
            this.TotalLabel.MinimumSize = new System.Drawing.Size(100, 20);
            this.TotalLabel.Name = "TotalLabel";
            this.TotalLabel.Size = new System.Drawing.Size(45, 19);
            this.TotalLabel.Style = MetroFramework.MetroColorStyle.Orange;
            this.TotalLabel.TabIndex = 14;
            this.TotalLabel.Text = "TOTAL";
            this.TotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.TotalLabel.UseStyleColors = true;
            this.TotalLabel.Click += new System.EventHandler(this.metroLabel1_Click);
            // 
            // IvaConLabel
            // 
            this.IvaConLabel.AutoSize = true;
            this.IvaConLabel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.IvaConLabel.Location = new System.Drawing.Point(577, 153);
            this.IvaConLabel.MinimumSize = new System.Drawing.Size(100, 20);
            this.IvaConLabel.Name = "IvaConLabel";
            this.IvaConLabel.Size = new System.Drawing.Size(0, 0);
            this.IvaConLabel.Style = MetroFramework.MetroColorStyle.Blue;
            this.IvaConLabel.TabIndex = 13;
            this.IvaConLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.IvaConLabel.UseStyleColors = true;
            // 
            // IVALabel
            // 
            this.IVALabel.AutoSize = true;
            this.IVALabel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.IVALabel.Location = new System.Drawing.Point(577, 133);
            this.IVALabel.MinimumSize = new System.Drawing.Size(100, 20);
            this.IVALabel.Name = "IVALabel";
            this.IVALabel.Size = new System.Drawing.Size(28, 19);
            this.IVALabel.Style = MetroFramework.MetroColorStyle.Orange;
            this.IVALabel.TabIndex = 12;
            this.IVALabel.Text = "IVA";
            this.IVALabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.IVALabel.UseStyleColors = true;
            // 
            // SubTotalConLabel
            // 
            this.SubTotalConLabel.AutoSize = true;
            this.SubTotalConLabel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.SubTotalConLabel.Location = new System.Drawing.Point(577, 113);
            this.SubTotalConLabel.MinimumSize = new System.Drawing.Size(100, 20);
            this.SubTotalConLabel.Name = "SubTotalConLabel";
            this.SubTotalConLabel.Size = new System.Drawing.Size(0, 0);
            this.SubTotalConLabel.Style = MetroFramework.MetroColorStyle.Blue;
            this.SubTotalConLabel.TabIndex = 11;
            this.SubTotalConLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.SubTotalConLabel.UseStyleColors = true;
            // 
            // CodeTextbox
            // 
            this.CodeTextbox.Location = new System.Drawing.Point(577, 58);
            this.CodeTextbox.Name = "CodeTextbox";
            this.CodeTextbox.Size = new System.Drawing.Size(150, 25);
            this.CodeTextbox.TabIndex = 10;
            this.CodeTextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CodeTextbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CodeTextbox_KeyPress);
            // 
            // SubTotalLabel
            // 
            this.SubTotalLabel.AutoSize = true;
            this.SubTotalLabel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.SubTotalLabel.Location = new System.Drawing.Point(577, 93);
            this.SubTotalLabel.MinimumSize = new System.Drawing.Size(100, 20);
            this.SubTotalLabel.Name = "SubTotalLabel";
            this.SubTotalLabel.Size = new System.Drawing.Size(58, 19);
            this.SubTotalLabel.Style = MetroFramework.MetroColorStyle.Orange;
            this.SubTotalLabel.TabIndex = 9;
            this.SubTotalLabel.Text = "SubTotal";
            this.SubTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.SubTotalLabel.UseStyleColors = true;
            // 
            // CodeLabel
            // 
            this.CodeLabel.AutoSize = true;
            this.CodeLabel.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.CodeLabel.Location = new System.Drawing.Point(577, 21);
            this.CodeLabel.MinimumSize = new System.Drawing.Size(100, 20);
            this.CodeLabel.Name = "CodeLabel";
            this.CodeLabel.Size = new System.Drawing.Size(53, 19);
            this.CodeLabel.Style = MetroFramework.MetroColorStyle.Orange;
            this.CodeLabel.TabIndex = 7;
            this.CodeLabel.Text = "Código";
            this.CodeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.CodeLabel.UseStyleColors = true;
            // 
            // ItemsDataGrid
            // 
            this.ItemsDataGrid.AllowUserToAddRows = false;
            this.ItemsDataGrid.AllowUserToResizeRows = false;
            this.ItemsDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ItemsDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ItemsDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.ItemsDataGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(219)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ItemsDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.ItemsDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(219)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ItemsDataGrid.DefaultCellStyle = dataGridViewCellStyle2;
            this.ItemsDataGrid.EnableHeadersVisualStyles = false;
            this.ItemsDataGrid.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.ItemsDataGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ItemsDataGrid.Location = new System.Drawing.Point(3, 3);
            this.ItemsDataGrid.Name = "ItemsDataGrid";
            this.ItemsDataGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(219)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ItemsDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.ItemsDataGrid.RowHeadersVisible = false;
            this.ItemsDataGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.ItemsDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ItemsDataGrid.Size = new System.Drawing.Size(552, 273);
            this.ItemsDataGrid.Style = MetroFramework.MetroColorStyle.Lime;
            this.ItemsDataGrid.TabIndex = 3;
            this.ItemsDataGrid.UseStyleColors = true;
            this.ItemsDataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ItemsDataGrid_CellContentClick);
            this.ItemsDataGrid.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.ItemsDataGrid_CellEndEdit);
            this.ItemsDataGrid.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.ItemsDataGrid_CellMouseUp);
            this.ItemsDataGrid.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.ItemsDataGrid_CellValidating);
            this.ItemsDataGrid.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.ItemsDataGrid_EditingControlShowing);
            // 
            // SyncNav
            // 
            this.SyncNav.BackColor = System.Drawing.Color.White;
            this.SyncNav.CausesValidation = false;
            this.SyncNav.Controls.Add(this.pictureBox13);
            this.SyncNav.Controls.Add(this.pictureBox14);
            this.SyncNav.Controls.Add(this.pictureBox12);
            this.SyncNav.Controls.Add(this.pictureBox11);
            this.SyncNav.Controls.Add(this.pictureBox10);
            this.SyncNav.Controls.Add(this.pictureBox9);
            this.SyncNav.Controls.Add(this.pictureBox8);
            this.SyncNav.Controls.Add(this.pictureBox7);
            this.SyncNav.Controls.Add(this.pictureBox6);
            this.SyncNav.Controls.Add(this.pictureBox5);
            this.SyncNav.Controls.Add(this.pictureBox4);
            this.SyncNav.Controls.Add(this.pictureBox1);
            this.SyncNav.Controls.Add(this.pictureBox3);
            this.SyncNav.Controls.Add(this.GetDatSuc);
            this.SyncNav.Controls.Add(this.GetDataComp);
            this.SyncNav.Controls.Add(this.MesureBar);
            this.SyncNav.Controls.Add(this.SyncMeasures);
            this.SyncNav.Controls.Add(this.progressItemsPrice);
            this.SyncNav.Controls.Add(this.metroTextButton3);
            this.SyncNav.Controls.Add(this.ProgressNavBanks);
            this.SyncNav.Controls.Add(this.SycnBanks);
            this.SyncNav.Controls.Add(this.UploadNav);
            this.SyncNav.Font = new System.Drawing.Font("Modern No. 20", 12F);
            this.SyncNav.HorizontalScrollbarBarColor = true;
            this.SyncNav.HorizontalScrollbarHighlightOnWheel = false;
            this.SyncNav.HorizontalScrollbarSize = 10;
            this.SyncNav.Location = new System.Drawing.Point(4, 44);
            this.SyncNav.Name = "SyncNav";
            this.SyncNav.Size = new System.Drawing.Size(739, 412);
            this.SyncNav.TabIndex = 2;
            this.SyncNav.Text = "Sincronización";
            this.SyncNav.VerticalScrollbarBarColor = true;
            this.SyncNav.VerticalScrollbarHighlightOnWheel = false;
            this.SyncNav.VerticalScrollbarSize = 10;
            this.SyncNav.Click += new System.EventHandler(this.TabNAV_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::ATX_POS.Properties.Resources._1472463246_file_add;
            this.pictureBox13.Location = new System.Drawing.Point(483, 276);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(65, 50);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 25;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::ATX_POS.Properties.Resources._1472463123_upload;
            this.pictureBox14.Location = new System.Drawing.Point(423, 276);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(61, 50);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox14.TabIndex = 24;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::ATX_POS.Properties.Resources._1472463742_Database_4;
            this.pictureBox12.Location = new System.Drawing.Point(213, 276);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(65, 50);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 23;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::ATX_POS.Properties.Resources._1472463468_dollar_exchange;
            this.pictureBox11.Location = new System.Drawing.Point(153, 276);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(61, 50);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 22;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::ATX_POS.Properties.Resources._1472462819_weight;
            this.pictureBox10.Location = new System.Drawing.Point(458, 139);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(65, 50);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 21;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::ATX_POS.Properties.Resources._1472459232_52_Cloud_Sync;
            this.pictureBox9.Location = new System.Drawing.Point(400, 139);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(61, 50);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 20;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::ATX_POS.Properties.Resources._1472461812_Bank;
            this.pictureBox8.Location = new System.Drawing.Point(251, 139);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(65, 50);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 19;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::ATX_POS.Properties.Resources._1472459232_52_Cloud_Sync;
            this.pictureBox7.Location = new System.Drawing.Point(191, 139);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(61, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 18;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::ATX_POS.Properties.Resources._1472461239_09;
            this.pictureBox6.Location = new System.Drawing.Point(485, 22);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(61, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 17;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::ATX_POS.Properties.Resources._1472460569_Database_Cloud;
            this.pictureBox5.Location = new System.Drawing.Point(423, 22);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(61, 50);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 16;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::ATX_POS.Properties.Resources._1472460955_agency;
            this.pictureBox4.Location = new System.Drawing.Point(213, 22);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(65, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 15;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ATX_POS.Properties.Resources._1472460569_Database_Cloud;
            this.pictureBox1.Location = new System.Drawing.Point(153, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.Image = global::ATX_POS.Properties.Resources._1472459650_cloud;
            this.pictureBox3.InitialImage = null;
            this.pictureBox3.Location = new System.Drawing.Point(624, 148);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(96, 89);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 13;
            this.pictureBox3.TabStop = false;
            // 
            // GetDatSuc
            // 
            this.GetDatSuc.Image = null;
            this.GetDatSuc.Location = new System.Drawing.Point(398, 78);
            this.GetDatSuc.Name = "GetDatSuc";
            this.GetDatSuc.Size = new System.Drawing.Size(173, 23);
            this.GetDatSuc.TabIndex = 11;
            this.GetDatSuc.Text = "Obtener Datos Sucursal";
            this.GetDatSuc.UseSelectable = true;
            this.GetDatSuc.UseVisualStyleBackColor = true;
            this.GetDatSuc.Click += new System.EventHandler(this.GetDatSuc_Click);
            // 
            // GetDataComp
            // 
            this.GetDataComp.Image = null;
            this.GetDataComp.Location = new System.Drawing.Point(126, 78);
            this.GetDataComp.Name = "GetDataComp";
            this.GetDataComp.Size = new System.Drawing.Size(173, 23);
            this.GetDataComp.TabIndex = 9;
            this.GetDataComp.Text = "Obtener Datos Empresa";
            this.GetDataComp.UseSelectable = true;
            this.GetDataComp.UseVisualStyleBackColor = true;
            this.GetDataComp.Click += new System.EventHandler(this.GetDataComp_Click);
            // 
            // MesureBar
            // 
            this.MesureBar.Location = new System.Drawing.Point(375, 224);
            this.MesureBar.Name = "MesureBar";
            this.MesureBar.Size = new System.Drawing.Size(173, 23);
            this.MesureBar.Style = MetroFramework.MetroColorStyle.Green;
            this.MesureBar.TabIndex = 8;
            this.MesureBar.UseCustomBackColor = true;
            // 
            // SyncMeasures
            // 
            this.SyncMeasures.Image = null;
            this.SyncMeasures.Location = new System.Drawing.Point(375, 195);
            this.SyncMeasures.Name = "SyncMeasures";
            this.SyncMeasures.Size = new System.Drawing.Size(173, 23);
            this.SyncMeasures.TabIndex = 7;
            this.SyncMeasures.Text = "Descargar Catalogo Medidas";
            this.SyncMeasures.UseSelectable = true;
            this.SyncMeasures.UseVisualStyleBackColor = true;
            this.SyncMeasures.Click += new System.EventHandler(this.metroTextButton4_Click);
            // 
            // progressItemsPrice
            // 
            this.progressItemsPrice.Location = new System.Drawing.Point(126, 361);
            this.progressItemsPrice.Name = "progressItemsPrice";
            this.progressItemsPrice.Size = new System.Drawing.Size(173, 23);
            this.progressItemsPrice.Style = MetroFramework.MetroColorStyle.Green;
            this.progressItemsPrice.TabIndex = 6;
            this.progressItemsPrice.UseCustomBackColor = true;
            // 
            // metroTextButton3
            // 
            this.metroTextButton3.Image = null;
            this.metroTextButton3.Location = new System.Drawing.Point(126, 332);
            this.metroTextButton3.Name = "metroTextButton3";
            this.metroTextButton3.Size = new System.Drawing.Size(173, 23);
            this.metroTextButton3.TabIndex = 5;
            this.metroTextButton3.Text = "Descargar Lista Precios";
            this.metroTextButton3.UseSelectable = true;
            this.metroTextButton3.UseVisualStyleBackColor = true;
            this.metroTextButton3.Click += new System.EventHandler(this.metroTextButton3_Click);
            // 
            // ProgressNavBanks
            // 
            this.ProgressNavBanks.Location = new System.Drawing.Point(164, 224);
            this.ProgressNavBanks.Name = "ProgressNavBanks";
            this.ProgressNavBanks.Size = new System.Drawing.Size(173, 23);
            this.ProgressNavBanks.Style = MetroFramework.MetroColorStyle.Green;
            this.ProgressNavBanks.TabIndex = 4;
            this.ProgressNavBanks.UseCustomBackColor = true;
            this.ProgressNavBanks.Click += new System.EventHandler(this.ProgressNavBanks_Click);
            // 
            // SycnBanks
            // 
            this.SycnBanks.Image = null;
            this.SycnBanks.Location = new System.Drawing.Point(164, 195);
            this.SycnBanks.Name = "SycnBanks";
            this.SycnBanks.Size = new System.Drawing.Size(173, 23);
            this.SycnBanks.TabIndex = 3;
            this.SycnBanks.Text = "Descargar Bancos NAV";
            this.SycnBanks.UseSelectable = true;
            this.SycnBanks.UseVisualStyleBackColor = true;
            this.SycnBanks.Click += new System.EventHandler(this.metroTextButton2_Click);
            // 
            // UploadNav
            // 
            this.UploadNav.Image = null;
            this.UploadNav.Location = new System.Drawing.Point(398, 332);
            this.UploadNav.Name = "UploadNav";
            this.UploadNav.Size = new System.Drawing.Size(173, 23);
            this.UploadNav.TabIndex = 2;
            this.UploadNav.Text = "Sincronizar Ventas a NAV";
            this.UploadNav.UseSelectable = true;
            this.UploadNav.UseVisualStyleBackColor = true;
            this.UploadNav.Click += new System.EventHandler(this.metroTextButton1_Click);
            // 
            // Config
            // 
            this.Config.Controls.Add(this.pictureBox17);
            this.Config.Controls.Add(this.metroTextButton4);
            this.Config.Controls.Add(this.metroTextButton2);
            this.Config.Controls.Add(this.metroTextButton1);
            this.Config.Controls.Add(this.metroLabel12);
            this.Config.Controls.Add(this.metroLabel11);
            this.Config.Controls.Add(this.Footer);
            this.Config.Controls.Add(this.metroLabel10);
            this.Config.Controls.Add(this.pictureBox16);
            this.Config.Controls.Add(this.TerminalConfig);
            this.Config.Controls.Add(this.pictureBox15);
            this.Config.Controls.Add(this.ConfigUsersboton);
            this.Config.Controls.Add(this.PhoneSuc);
            this.Config.Controls.Add(this.metroLabel8);
            this.Config.Controls.Add(this.CodeNavStore);
            this.Config.Controls.Add(this.metroLabel9);
            this.Config.Controls.Add(this.CompanyPhone);
            this.Config.Controls.Add(this.metroLabel6);
            this.Config.Controls.Add(this.LocSucText);
            this.Config.Controls.Add(this.metroLabel7);
            this.Config.Controls.Add(this.SucNameText);
            this.Config.Controls.Add(this.metroLabel5);
            this.Config.Controls.Add(this.RFC);
            this.Config.Controls.Add(this.metroLabel4);
            this.Config.Controls.Add(this.CompanyLocation);
            this.Config.Controls.Add(this.metroLabel3);
            this.Config.Controls.Add(this.NameCompany);
            this.Config.Controls.Add(this.metroLabel2);
            this.Config.HorizontalScrollbarBarColor = true;
            this.Config.HorizontalScrollbarHighlightOnWheel = false;
            this.Config.HorizontalScrollbarSize = 10;
            this.Config.Location = new System.Drawing.Point(4, 44);
            this.Config.Name = "Config";
            this.Config.Size = new System.Drawing.Size(739, 412);
            this.Config.TabIndex = 3;
            this.Config.Text = "Configuración";
            this.Config.VerticalScrollbarBarColor = true;
            this.Config.VerticalScrollbarHighlightOnWheel = false;
            this.Config.VerticalScrollbarSize = 10;
            this.Config.Click += new System.EventHandler(this.Config_Click);
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.White;
            this.pictureBox17.Image = global::ATX_POS.Properties.Resources._1474428288_Application;
            this.pictureBox17.Location = new System.Drawing.Point(501, 190);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(84, 63);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox17.TabIndex = 29;
            this.pictureBox17.TabStop = false;
            // 
            // metroTextButton4
            // 
            this.metroTextButton4.Image = null;
            this.metroTextButton4.Location = new System.Drawing.Point(473, 259);
            this.metroTextButton4.Name = "metroTextButton4";
            this.metroTextButton4.Size = new System.Drawing.Size(139, 23);
            this.metroTextButton4.Style = MetroFramework.MetroColorStyle.Purple;
            this.metroTextButton4.TabIndex = 28;
            this.metroTextButton4.Text = "Configuración Cuentas";
            this.metroTextButton4.UseSelectable = true;
            this.metroTextButton4.UseStyleColors = true;
            this.metroTextButton4.UseVisualStyleBackColor = true;
            this.metroTextButton4.Click += new System.EventHandler(this.metroTextButton4_Click_1);
            // 
            // metroTextButton2
            // 
            this.metroTextButton2.Image = null;
            this.metroTextButton2.Location = new System.Drawing.Point(3, 378);
            this.metroTextButton2.Name = "metroTextButton2";
            this.metroTextButton2.Size = new System.Drawing.Size(94, 23);
            this.metroTextButton2.Style = MetroFramework.MetroColorStyle.Purple;
            this.metroTextButton2.TabIndex = 27;
            this.metroTextButton2.Text = "Editar Leyenda";
            this.metroTextButton2.UseSelectable = true;
            this.metroTextButton2.UseStyleColors = true;
            this.metroTextButton2.UseVisualStyleBackColor = false;
            this.metroTextButton2.Click += new System.EventHandler(this.metroTextButton2_Click_1);
            // 
            // metroTextButton1
            // 
            this.metroTextButton1.Image = null;
            this.metroTextButton1.Location = new System.Drawing.Point(143, 378);
            this.metroTextButton1.Name = "metroTextButton1";
            this.metroTextButton1.Size = new System.Drawing.Size(139, 23);
            this.metroTextButton1.Style = MetroFramework.MetroColorStyle.Purple;
            this.metroTextButton1.TabIndex = 26;
            this.metroTextButton1.Text = "Actualizar Leyenda Ticket";
            this.metroTextButton1.UseSelectable = true;
            this.metroTextButton1.UseStyleColors = true;
            this.metroTextButton1.UseVisualStyleBackColor = true;
            this.metroTextButton1.Click += new System.EventHandler(this.metroTextButton1_Click_1);
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(0, 356);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(129, 19);
            this.metroLabel12.Style = MetroFramework.MetroColorStyle.Brown;
            this.metroLabel12.TabIndex = 25;
            this.metroLabel12.Text = "Caracteres Restantes";
            this.metroLabel12.UseStyleColors = true;
            this.metroLabel12.Visible = false;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(168, 356);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(30, 19);
            this.metroLabel11.Style = MetroFramework.MetroColorStyle.Brown;
            this.metroLabel11.TabIndex = 24;
            this.metroLabel11.Text = "499";
            this.metroLabel11.UseStyleColors = true;
            this.metroLabel11.Visible = false;
            // 
            // Footer
            // 
            this.Footer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Footer.Location = new System.Drawing.Point(0, 237);
            this.Footer.MaxLength = 499;
            this.Footer.Multiline = true;
            this.Footer.Name = "Footer";
            this.Footer.ReadOnly = true;
            this.Footer.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Footer.Size = new System.Drawing.Size(282, 116);
            this.Footer.TabIndex = 23;
            this.Footer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(3, 215);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(94, 19);
            this.metroLabel10.Style = MetroFramework.MetroColorStyle.Brown;
            this.metroLabel10.TabIndex = 22;
            this.metroLabel10.Text = "Leyenda Ticket";
            this.metroLabel10.UseStyleColors = true;
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.White;
            this.pictureBox16.Image = global::ATX_POS.Properties.Resources._1472769247_cash_register;
            this.pictureBox16.Location = new System.Drawing.Point(405, 288);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(100, 69);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox16.TabIndex = 21;
            this.pictureBox16.TabStop = false;
            // 
            // TerminalConfig
            // 
            this.TerminalConfig.Image = null;
            this.TerminalConfig.Location = new System.Drawing.Point(388, 363);
            this.TerminalConfig.Name = "TerminalConfig";
            this.TerminalConfig.Size = new System.Drawing.Size(139, 23);
            this.TerminalConfig.Style = MetroFramework.MetroColorStyle.Purple;
            this.TerminalConfig.TabIndex = 20;
            this.TerminalConfig.Text = "Configuración Terminales";
            this.TerminalConfig.UseSelectable = true;
            this.TerminalConfig.UseStyleColors = true;
            this.TerminalConfig.UseVisualStyleBackColor = true;
            this.TerminalConfig.Click += new System.EventHandler(this.TerminalConfig_Click);
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.White;
            this.pictureBox15.Image = global::ATX_POS.Properties.Resources._1472768732_user_accounts_config;
            this.pictureBox15.Location = new System.Drawing.Point(579, 288);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(100, 69);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox15.TabIndex = 19;
            this.pictureBox15.TabStop = false;
            // 
            // ConfigUsersboton
            // 
            this.ConfigUsersboton.Image = null;
            this.ConfigUsersboton.Location = new System.Drawing.Point(563, 363);
            this.ConfigUsersboton.Name = "ConfigUsersboton";
            this.ConfigUsersboton.Size = new System.Drawing.Size(139, 23);
            this.ConfigUsersboton.Style = MetroFramework.MetroColorStyle.Purple;
            this.ConfigUsersboton.TabIndex = 18;
            this.ConfigUsersboton.Text = "Configuración Usuarios";
            this.ConfigUsersboton.UseSelectable = true;
            this.ConfigUsersboton.UseStyleColors = true;
            this.ConfigUsersboton.UseVisualStyleBackColor = true;
            this.ConfigUsersboton.Click += new System.EventHandler(this.ConfigUsers_Click);
            // 
            // PhoneSuc
            // 
            this.PhoneSuc.Location = new System.Drawing.Point(583, 164);
            this.PhoneSuc.Name = "PhoneSuc";
            this.PhoneSuc.ReadOnly = true;
            this.PhoneSuc.Size = new System.Drawing.Size(102, 20);
            this.PhoneSuc.TabIndex = 17;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(583, 142);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(58, 19);
            this.metroLabel8.Style = MetroFramework.MetroColorStyle.Brown;
            this.metroLabel8.TabIndex = 16;
            this.metroLabel8.Text = "Télefono";
            this.metroLabel8.UseStyleColors = true;
            // 
            // CodeNavStore
            // 
            this.CodeNavStore.Location = new System.Drawing.Point(406, 164);
            this.CodeNavStore.Name = "CodeNavStore";
            this.CodeNavStore.ReadOnly = true;
            this.CodeNavStore.Size = new System.Drawing.Size(111, 20);
            this.CodeNavStore.TabIndex = 15;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(406, 142);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(108, 19);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Brown;
            this.metroLabel9.TabIndex = 14;
            this.metroLabel9.Text = "Código Almacen";
            this.metroLabel9.UseStyleColors = true;
            // 
            // CompanyPhone
            // 
            this.CompanyPhone.Location = new System.Drawing.Point(168, 164);
            this.CompanyPhone.Name = "CompanyPhone";
            this.CompanyPhone.ReadOnly = true;
            this.CompanyPhone.Size = new System.Drawing.Size(114, 20);
            this.CompanyPhone.TabIndex = 13;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(168, 142);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(58, 19);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Brown;
            this.metroLabel6.TabIndex = 12;
            this.metroLabel6.Text = "Télefono";
            this.metroLabel6.UseStyleColors = true;
            // 
            // LocSucText
            // 
            this.LocSucText.Location = new System.Drawing.Point(406, 98);
            this.LocSucText.Multiline = true;
            this.LocSucText.Name = "LocSucText";
            this.LocSucText.ReadOnly = true;
            this.LocSucText.Size = new System.Drawing.Size(282, 41);
            this.LocSucText.TabIndex = 11;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(409, 76);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(63, 19);
            this.metroLabel7.Style = MetroFramework.MetroColorStyle.Brown;
            this.metroLabel7.TabIndex = 10;
            this.metroLabel7.Text = "Dirección";
            this.metroLabel7.UseStyleColors = true;
            // 
            // SucNameText
            // 
            this.SucNameText.Location = new System.Drawing.Point(406, 44);
            this.SucNameText.Name = "SucNameText";
            this.SucNameText.ReadOnly = true;
            this.SucNameText.Size = new System.Drawing.Size(135, 20);
            this.SucNameText.TabIndex = 9;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(406, 22);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(110, 19);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Brown;
            this.metroLabel5.TabIndex = 8;
            this.metroLabel5.Text = "Nombre Sucursal";
            this.metroLabel5.UseStyleColors = true;
            // 
            // RFC
            // 
            this.RFC.Location = new System.Drawing.Point(0, 164);
            this.RFC.Name = "RFC";
            this.RFC.ReadOnly = true;
            this.RFC.Size = new System.Drawing.Size(111, 20);
            this.RFC.TabIndex = 7;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(3, 142);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(33, 19);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Brown;
            this.metroLabel4.TabIndex = 6;
            this.metroLabel4.Text = "RFC";
            this.metroLabel4.UseStyleColors = true;
            // 
            // CompanyLocation
            // 
            this.CompanyLocation.Location = new System.Drawing.Point(0, 98);
            this.CompanyLocation.Multiline = true;
            this.CompanyLocation.Name = "CompanyLocation";
            this.CompanyLocation.ReadOnly = true;
            this.CompanyLocation.Size = new System.Drawing.Size(282, 41);
            this.CompanyLocation.TabIndex = 5;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(3, 76);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(63, 19);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Brown;
            this.metroLabel3.TabIndex = 4;
            this.metroLabel3.Text = "Dirección";
            this.metroLabel3.UseStyleColors = true;
            // 
            // NameCompany
            // 
            this.NameCompany.Location = new System.Drawing.Point(3, 44);
            this.NameCompany.Name = "NameCompany";
            this.NameCompany.ReadOnly = true;
            this.NameCompany.Size = new System.Drawing.Size(279, 20);
            this.NameCompany.TabIndex = 3;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(3, 22);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(124, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Brown;
            this.metroLabel2.TabIndex = 2;
            this.metroLabel2.Text = "Nombre Compañia";
            this.metroLabel2.UseStyleColors = true;
            // 
            // TabCashOut
            // 
            this.TabCashOut.CausesValidation = false;
            this.TabCashOut.Controls.Add(this.CashManualOut);
            this.TabCashOut.Controls.Add(this.CorteCaja);
            this.TabCashOut.Controls.Add(this.CorteFin);
            this.TabCashOut.Controls.Add(this.TermAsing);
            this.TabCashOut.Controls.Add(this.UseTerminal);
            this.TabCashOut.Controls.Add(this.salesInDetail1);
            this.TabCashOut.Controls.Add(this.metroLabel1);
            this.TabCashOut.Controls.Add(this.pictureBox2);
            this.TabCashOut.Controls.Add(this.SalesLabelContent);
            this.TabCashOut.Controls.Add(this.SalesTotalLabel);
            this.TabCashOut.Controls.Add(this.CurrencyPicture);
            this.TabCashOut.Controls.Add(this.NameUserLabelCont);
            this.TabCashOut.Controls.Add(this.UserNameLabel);
            this.TabCashOut.Controls.Add(this.ListOfUsers);
            this.TabCashOut.Controls.Add(this.ImagenUser);
            this.TabCashOut.Controls.Add(this.cashCount1);
            this.TabCashOut.Font = new System.Drawing.Font("Modern No. 20", 12F);
            this.TabCashOut.HorizontalScrollbarBarColor = true;
            this.TabCashOut.HorizontalScrollbarHighlightOnWheel = false;
            this.TabCashOut.HorizontalScrollbarSize = 10;
            this.TabCashOut.Location = new System.Drawing.Point(4, 44);
            this.TabCashOut.Name = "TabCashOut";
            this.TabCashOut.Size = new System.Drawing.Size(739, 412);
            this.TabCashOut.TabIndex = 1;
            this.TabCashOut.Text = "Corte Caja";
            this.TabCashOut.VerticalScrollbarBarColor = true;
            this.TabCashOut.VerticalScrollbarHighlightOnWheel = false;
            this.TabCashOut.VerticalScrollbarSize = 10;
            this.TabCashOut.Click += new System.EventHandler(this.TabCashOut_Click);
            // 
            // CashManualOut
            // 
            this.CashManualOut.Image = null;
            this.CashManualOut.Location = new System.Drawing.Point(604, 328);
            this.CashManualOut.Name = "CashManualOut";
            this.CashManualOut.Size = new System.Drawing.Size(132, 23);
            this.CashManualOut.TabIndex = 18;
            this.CashManualOut.Text = "Retiro de Efectivo";
            this.CashManualOut.UseSelectable = true;
            this.CashManualOut.UseVisualStyleBackColor = true;
            this.CashManualOut.Click += new System.EventHandler(this.CashManualOut_Click);
            // 
            // CorteCaja
            // 
            this.CorteCaja.Image = null;
            this.CorteCaja.Location = new System.Drawing.Point(541, 328);
            this.CorteCaja.Name = "CorteCaja";
            this.CorteCaja.Size = new System.Drawing.Size(132, 23);
            this.CorteCaja.TabIndex = 8;
            this.CorteCaja.Text = "Corte Turno";
            this.CorteCaja.UseSelectable = true;
            this.CorteCaja.UseVisualStyleBackColor = true;
            this.CorteCaja.Click += new System.EventHandler(this.CorteCaja_Click);
            // 
            // CorteFin
            // 
            this.CorteFin.Image = null;
            this.CorteFin.Location = new System.Drawing.Point(403, 327);
            this.CorteFin.Name = "CorteFin";
            this.CorteFin.Size = new System.Drawing.Size(132, 23);
            this.CorteFin.TabIndex = 9;
            this.CorteFin.Text = "Corte Caja";
            this.CorteFin.UseSelectable = true;
            this.CorteFin.UseVisualStyleBackColor = true;
            this.CorteFin.Click += new System.EventHandler(this.CorteFin_Click);
            // 
            // TermAsing
            // 
            this.TermAsing.AutoSize = true;
            this.TermAsing.Location = new System.Drawing.Point(340, 71);
            this.TermAsing.MinimumSize = new System.Drawing.Size(50, 19);
            this.TermAsing.Name = "TermAsing";
            this.TermAsing.Size = new System.Drawing.Size(0, 0);
            this.TermAsing.Style = MetroFramework.MetroColorStyle.Blue;
            this.TermAsing.TabIndex = 17;
            this.TermAsing.UseStyleColors = true;
            // 
            // UseTerminal
            // 
            this.UseTerminal.AutoSize = true;
            this.UseTerminal.Location = new System.Drawing.Point(323, 46);
            this.UseTerminal.Name = "UseTerminal";
            this.UseTerminal.Size = new System.Drawing.Size(116, 19);
            this.UseTerminal.TabIndex = 16;
            this.UseTerminal.Text = "Terminal Asignada";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(70, 197);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(96, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroLabel1.TabIndex = 12;
            this.metroLabel1.Text = "Dinero en Caja";
            this.metroLabel1.UseStyleColors = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::ATX_POS.Properties.Resources._1464294622_window_charts_graphs;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.ErrorImage = null;
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(18, 182);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(46, 46);
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // SalesLabelContent
            // 
            this.SalesLabelContent.AutoSize = true;
            this.SalesLabelContent.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.SalesLabelContent.Location = new System.Drawing.Point(152, 124);
            this.SalesLabelContent.MinimumSize = new System.Drawing.Size(150, 30);
            this.SalesLabelContent.Name = "SalesLabelContent";
            this.SalesLabelContent.Size = new System.Drawing.Size(0, 0);
            this.SalesLabelContent.Style = MetroFramework.MetroColorStyle.Lime;
            this.SalesLabelContent.TabIndex = 10;
            this.SalesLabelContent.UseStyleColors = true;
            // 
            // SalesTotalLabel
            // 
            this.SalesTotalLabel.AutoSize = true;
            this.SalesTotalLabel.Location = new System.Drawing.Point(70, 130);
            this.SalesTotalLabel.Name = "SalesTotalLabel";
            this.SalesTotalLabel.Size = new System.Drawing.Size(77, 19);
            this.SalesTotalLabel.Style = MetroFramework.MetroColorStyle.Orange;
            this.SalesTotalLabel.TabIndex = 9;
            this.SalesTotalLabel.Text = "Total Ventas";
            this.SalesTotalLabel.UseStyleColors = true;
            // 
            // CurrencyPicture
            // 
            this.CurrencyPicture.BackColor = System.Drawing.Color.Transparent;
            this.CurrencyPicture.BackgroundImage = global::ATX_POS.Properties.Resources._1463716407_circle_dollar;
            this.CurrencyPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.CurrencyPicture.ErrorImage = null;
            this.CurrencyPicture.InitialImage = null;
            this.CurrencyPicture.Location = new System.Drawing.Point(18, 118);
            this.CurrencyPicture.Margin = new System.Windows.Forms.Padding(0);
            this.CurrencyPicture.Name = "CurrencyPicture";
            this.CurrencyPicture.Size = new System.Drawing.Size(46, 41);
            this.CurrencyPicture.TabIndex = 8;
            this.CurrencyPicture.TabStop = false;
            // 
            // NameUserLabelCont
            // 
            this.NameUserLabelCont.AutoSize = true;
            this.NameUserLabelCont.Location = new System.Drawing.Point(102, 65);
            this.NameUserLabelCont.MinimumSize = new System.Drawing.Size(200, 25);
            this.NameUserLabelCont.Name = "NameUserLabelCont";
            this.NameUserLabelCont.Size = new System.Drawing.Size(0, 0);
            this.NameUserLabelCont.Style = MetroFramework.MetroColorStyle.Purple;
            this.NameUserLabelCont.TabIndex = 5;
            this.NameUserLabelCont.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.NameUserLabelCont.UseStyleColors = true;
            // 
            // UserNameLabel
            // 
            this.UserNameLabel.AutoSize = true;
            this.UserNameLabel.Location = new System.Drawing.Point(145, 44);
            this.UserNameLabel.Name = "UserNameLabel";
            this.UserNameLabel.Size = new System.Drawing.Size(107, 19);
            this.UserNameLabel.TabIndex = 4;
            this.UserNameLabel.Text = "Nombre Usuario";
            this.UserNameLabel.Click += new System.EventHandler(this.metroLabel1_Click_1);
            // 
            // ListOfUsers
            // 
            this.ListOfUsers.FormattingEnabled = true;
            this.ListOfUsers.ItemHeight = 23;
            this.ListOfUsers.Location = new System.Drawing.Point(102, 12);
            this.ListOfUsers.MinimumSize = new System.Drawing.Size(200, 0);
            this.ListOfUsers.Name = "ListOfUsers";
            this.ListOfUsers.Size = new System.Drawing.Size(200, 29);
            this.ListOfUsers.Style = MetroFramework.MetroColorStyle.Teal;
            this.ListOfUsers.TabIndex = 3;
            this.ListOfUsers.UseSelectable = true;
            this.ListOfUsers.UseStyleColors = true;
            this.ListOfUsers.SelectedIndexChanged += new System.EventHandler(this.ListOfUsers_SelectedIndexChanged);
            this.ListOfUsers.Click += new System.EventHandler(this.ValidaUser);
            // 
            // ImagenUser
            // 
            this.ImagenUser.BackColor = System.Drawing.Color.Transparent;
            this.ImagenUser.BackgroundImage = global::ATX_POS.Properties.Resources.user_icon_png_pnglogocom;
            this.ImagenUser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ImagenUser.ErrorImage = null;
            this.ImagenUser.InitialImage = null;
            this.ImagenUser.Location = new System.Drawing.Point(3, 3);
            this.ImagenUser.MaximumSize = new System.Drawing.Size(93, 87);
            this.ImagenUser.MinimumSize = new System.Drawing.Size(93, 87);
            this.ImagenUser.Name = "ImagenUser";
            this.ImagenUser.Size = new System.Drawing.Size(93, 87);
            this.ImagenUser.TabIndex = 2;
            this.ImagenUser.TabStop = false;
            // 
            // labelUser
            // 
            this.labelUser.AutoSize = true;
            this.labelUser.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(116)))), ((int)(((byte)(18)))));
            this.labelUser.Location = new System.Drawing.Point(515, 60);
            this.labelUser.MinimumSize = new System.Drawing.Size(30, 20);
            this.labelUser.Name = "labelUser";
            this.labelUser.Size = new System.Drawing.Size(67, 20);
            this.labelUser.TabIndex = 2;
            this.labelUser.Text = "Usuario: ";
            // 
            // UserLabel
            // 
            this.UserLabel.AutoSize = true;
            this.UserLabel.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(36)))), ((int)(((byte)(178)))));
            this.UserLabel.Location = new System.Drawing.Point(578, 60);
            this.UserLabel.MinimumSize = new System.Drawing.Size(80, 20);
            this.UserLabel.Name = "UserLabel";
            this.UserLabel.Size = new System.Drawing.Size(80, 20);
            this.UserLabel.TabIndex = 3;
            // 
            // LabelTerminal
            // 
            this.LabelTerminal.AutoSize = true;
            this.LabelTerminal.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelTerminal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(116)))), ((int)(((byte)(18)))));
            this.LabelTerminal.Location = new System.Drawing.Point(638, 60);
            this.LabelTerminal.MinimumSize = new System.Drawing.Size(30, 20);
            this.LabelTerminal.Name = "LabelTerminal";
            this.LabelTerminal.Size = new System.Drawing.Size(77, 20);
            this.LabelTerminal.TabIndex = 4;
            this.LabelTerminal.Text = "Terminal: ";
            this.LabelTerminal.Click += new System.EventHandler(this.LabelTerminal_Click);
            // 
            // MenuGrid
            // 
            this.MenuGrid.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BorrarArticulo});
            this.MenuGrid.Name = "MenuGrid";
            this.MenuGrid.Size = new System.Drawing.Size(153, 26);
            this.MenuGrid.Style = MetroFramework.MetroColorStyle.Blue;
            this.MenuGrid.UseStyleColors = true;
            // 
            // BorrarArticulo
            // 
            this.BorrarArticulo.Name = "BorrarArticulo";
            this.BorrarArticulo.Size = new System.Drawing.Size(152, 22);
            this.BorrarArticulo.Text = "Quitar Articulo";
            this.BorrarArticulo.Click += new System.EventHandler(this.LineaMarcada);
            // 
            // TimerLabel
            // 
            this.TimerLabel.AutoSize = true;
            this.TimerLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.TimerLabel.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.TimerLabel.ForeColor = System.Drawing.Color.DarkOrange;
            this.TimerLabel.Location = new System.Drawing.Point(641, 20);
            this.TimerLabel.Name = "TimerLabel";
            this.TimerLabel.Size = new System.Drawing.Size(82, 25);
            this.TimerLabel.Style = MetroFramework.MetroColorStyle.Teal;
            this.TimerLabel.TabIndex = 6;
            this.TimerLabel.Text = "00:00:00";
            this.TimerLabel.UseStyleColors = true;
            // 
            // NoTerminal
            // 
            this.NoTerminal.AutoSize = true;
            this.NoTerminal.Location = new System.Drawing.Point(712, 60);
            this.NoTerminal.MinimumSize = new System.Drawing.Size(30, 20);
            this.NoTerminal.Name = "NoTerminal";
            this.NoTerminal.Size = new System.Drawing.Size(0, 0);
            this.NoTerminal.Style = MetroFramework.MetroColorStyle.Purple;
            this.NoTerminal.TabIndex = 7;
            this.NoTerminal.UseStyleColors = true;
            // 
            // Logo
            // 
            this.Logo.Image = global::ATX_POS.Properties.Resources.Salud;
            this.Logo.Location = new System.Drawing.Point(229, 8);
            this.Logo.MinimumSize = new System.Drawing.Size(80, 80);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(80, 80);
            this.Logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Logo.TabIndex = 1;
            this.Logo.TabStop = false;
            // 
            // LogOut
            // 
            this.LogOut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogOut.Image = global::ATX_POS.Properties.Resources._1473108859_free_29;
            this.LogOut.Location = new System.Drawing.Point(754, 20);
            this.LogOut.Name = "LogOut";
            this.LogOut.Size = new System.Drawing.Size(23, 25);
            this.LogOut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.LogOut.TabIndex = 8;
            this.LogOut.TabStop = false;
            this.LogOut.Click += new System.EventHandler(this.LogOut_Click);
            // 
            // salesInDetail1
            // 
            this.salesInDetail1.BackColor = System.Drawing.Color.Transparent;
            this.salesInDetail1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.salesInDetail1.Location = new System.Drawing.Point(412, 29);
            this.salesInDetail1.Margin = new System.Windows.Forms.Padding(4);
            this.salesInDetail1.Name = "salesInDetail1";
            this.salesInDetail1.Size = new System.Drawing.Size(323, 259);
            this.salesInDetail1.TabIndex = 15;
            // 
            // cashCount1
            // 
            this.cashCount1.BackColor = System.Drawing.Color.Transparent;
            this.cashCount1.Location = new System.Drawing.Point(30, 234);
            this.cashCount1.Margin = new System.Windows.Forms.Padding(6);
            this.cashCount1.Name = "cashCount1";
            this.cashCount1.Size = new System.Drawing.Size(345, 182);
            this.cashCount1.TabIndex = 14;
            this.cashCount1.Load += new System.EventHandler(this.cashCount1_Load);
            // 
            // SyncPriceLists
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ATX_POS.Properties.Resources.navonazurelogo_azul;
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.LogOut);
            this.Controls.Add(this.NoTerminal);
            this.Controls.Add(this.LabelTerminal);
            this.Controls.Add(this.TimerLabel);
            this.Controls.Add(this.UserLabel);
            this.Controls.Add(this.labelUser);
            this.Controls.Add(this.TabsPOS);
            this.Controls.Add(this.Logo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Movable = false;
            this.Name = "SyncPriceLists";
            this.Opacity = 0.95D;
            this.Resizable = false;
            this.Text = "Dirección";
            this.Theme = MetroFramework.MetroThemeStyle.Default;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Sistemapos_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.SistemaPos_FormClosed);
            this.Load += new System.EventHandler(this.SistemaPos_Load);
            this.Resize += new System.EventHandler(this.SistemaPos_Load);
            this.TabsPOS.ResumeLayout(false);
            this.TabTerminal.ResumeLayout(false);
            this.TabTerminal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ItemsDataGrid)).EndInit();
            this.SyncNav.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.Config.ResumeLayout(false);
            this.Config.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            this.TabCashOut.ResumeLayout(false);
            this.TabCashOut.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CurrencyPicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImagenUser)).EndInit();
            this.MenuGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogOut)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl TabsPOS;
        private MetroFramework.Controls.MetroTabPage TabTerminal;
        private MetroFramework.Controls.MetroTabPage TabCashOut;
        private MetroFramework.Controls.MetroTabPage SyncNav;
        private System.Windows.Forms.PictureBox Logo;
        private System.Windows.Forms.Label labelUser;
        private System.Windows.Forms.Label LabelTerminal;
        private MetroFramework.Controls.MetroGrid ItemsDataGrid;
        private MetroFramework.Controls.MetroLabel SubTotalLabel;
        private MetroFramework.Controls.MetroLabel CodeLabel;
        private System.Windows.Forms.TextBox CodeTextbox;
        private MetroFramework.Controls.MetroLabel SubTotalConLabel;
        private MetroFramework.Controls.MetroLabel IvaConLabel;
        private MetroFramework.Controls.MetroLabel IVALabel;
        private MetroFramework.Controls.MetroLabel TotalLabel;
        private MetroFramework.Controls.MetroLabel TotalConten;
        private MetroFramework.Controls.MetroTile RegistrarVenta;
        private MetroFramework.Controls.MetroContextMenu MenuGrid;
        private System.Windows.Forms.ToolStripMenuItem BorrarArticulo;
        private System.Windows.Forms.PictureBox ImagenUser;
        private MetroFramework.Controls.MetroComboBox ListOfUsers;
        private MetroFramework.Controls.MetroLabel UserNameLabel;
        private MetroFramework.Controls.MetroLabel NameUserLabelCont;
        private System.Windows.Forms.PictureBox CurrencyPicture;
        private MetroFramework.Controls.MetroLabel SalesTotalLabel;
        private MetroFramework.Controls.MetroLabel SalesLabelContent;
        private System.Windows.Forms.PictureBox pictureBox2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private CashCount cashCount1;
        public System.Windows.Forms.Label UserLabel;
        private MetroFramework.Controls.MetroLabel TimerLabel;
        public MetroFramework.Controls.MetroLabel NoTerminal;
        private SalesInDetail salesInDetail1;
        private MetroFramework.Controls.MetroLabel UseTerminal;
        private MetroFramework.Controls.MetroLabel TermAsing;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton CorteCaja;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton CorteFin;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton UploadNav;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton SycnBanks;
        public MetroFramework.Controls.MetroProgressBar ProgressNavBanks;
        public MetroFramework.Controls.MetroProgressBar progressItemsPrice;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton metroTextButton3;
        public MetroFramework.Controls.MetroProgressBar MesureBar;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton SyncMeasures;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton CashManualOut;
        private MetroFramework.Controls.MetroTabPage Config;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton GetDatSuc;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton GetDataComp;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox15;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton ConfigUsersboton;
        private System.Windows.Forms.TextBox PhoneSuc;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private System.Windows.Forms.TextBox CodeNavStore;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private System.Windows.Forms.TextBox CompanyPhone;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.TextBox LocSucText;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private System.Windows.Forms.TextBox SucNameText;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private System.Windows.Forms.TextBox RFC;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.TextBox CompanyLocation;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private System.Windows.Forms.TextBox NameCompany;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private System.Windows.Forms.PictureBox pictureBox16;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton TerminalConfig;
        private System.Windows.Forms.PictureBox LogOut;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton metroTextButton1;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private System.Windows.Forms.TextBox Footer;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton metroTextButton2;
        private System.Windows.Forms.PictureBox pictureBox17;
        private MetroFramework.Controls.MetroTextBox.MetroTextButton metroTextButton4;
    }
}